<div class="jumbotron detail-jumbo">
    <h1 class="display-4">{{ $title }}</h1>
    @isset($introduction)
        <p class="lead">{{ $introduction }}</p>
    @endisset
    <hr class="mt-0 mb-4">
    {{ $slot }}
</div>
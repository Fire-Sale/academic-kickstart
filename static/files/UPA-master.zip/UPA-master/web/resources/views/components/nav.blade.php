<nav class="navbar navbar-light bg-light navbar-expand-lg">
    <div class="container">
        <img src="{{ url('img/flag.png') }}" class="img-fluid mr-2" style="max-height: 2.4rem;" id="logo">
        <a class="navbar-brand" href="{{ route('index') }}">{{ config('app.name') }}</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item {{ Request::is('/') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('index') }}">主页</a>
                </li>
                <li class="nav-item {{ Request::is('areas*') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('areas.index') }}">巡航</a>
                </li>
                <li class="nav-item {{ Request::is('devices*') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('devices.index') }}">设备</a>
                </li>
                <li class="nav-item {{ Request::is('records*') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('records.index') }}">记录</a>
                </li>
            </ul>

            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link">
                        <span class="badge badge-success">
                            <ion-icon name="paper-plane"></ion-icon>
                            在线：0
                        </span>
                    </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link">
                        <span class="badge badge-info">
                            <ion-icon name="play"></ion-icon>
                            执行中：0
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
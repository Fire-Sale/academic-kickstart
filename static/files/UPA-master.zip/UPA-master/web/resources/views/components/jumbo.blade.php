<div class="jumbotron app-jumbo">
    <h1 class="display-4" id="jumbo-title">{{ $title }}</h1>
    @isset($introduction)
        <p class="lead">{{ $introduction }}</p>
    @endisset
    <hr class="my-4">
    {{ $slot }}
</div>
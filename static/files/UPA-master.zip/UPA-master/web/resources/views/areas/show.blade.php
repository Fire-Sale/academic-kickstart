@extends('layouts.app')

@section('page_title')
    {{ $area->name }} - @parent
@endsection

@section('content')
    @component('components.jumbo-detail')
        @slot('title')
            {{ $area->name }}
            <small>
                <button type="button" class="btn btn-outline-danger" data-toggle="modal"
                        data-target="#delete-area-modal">
                    删除
                </button>
            </small>
        @endslot
        @if (session('success'))
            @alert(['type'=>'success'])
            {{ session('success') }}
            @endalert
        @endif
        @if (session('error'))
            @alert(['type'=>'danger'])
            {{ session('error') }}
            @endalert
        @endif
        @include('components.errors')
        <div class="row">
            <div class="col">
                <div id='map'></div>
                <div class='calculation-box'>
                    <p class="mb-0">所选面积 (㎡)</p>
                    <div id='calculated-area'><b>{{ $area->parameters["size"] }}</b></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <form class="mt-4">
                    <div class="form-group row">
                        <label for="area-type-urban" class="col-md-4 col-form-label text-md-right pt-0">地区</label>

                        <div class="col-md-6">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="area-type-urban" class="custom-control-input"
                                       value="urban" required
                                       {{ $area->parameters["area_type"] == 'urban' ? ' checked' : ''}} disabled>
                                <label class="custom-control-label" for="area-type-urban">城市</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="area-type-rural" class="custom-control-input"
                                       value="rural"
                                       {{ $area->parameters["area_type"] == 'rural' ? 'checked' : ''}} disabled>
                                <label class="custom-control-label" for="area-type-rural">乡村</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="min-height" class="col-md-4 col-form-label text-md-right">最小高度（米）</label>

                        <div class="col-md-6">
                            <input id="min-height" type="text" class="form-control"
                                   value="{{ $area->parameters['min_height'] }}" disabled>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="max-height" class="col-md-4 col-form-label text-md-right">最大高度（米）</label>

                        <div class="col-md-6">
                            <input id="max-height" type="text" class="form-control"
                                   value="{{ $area->parameters["max_height"] }}" disabled>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="return-height" class="col-md-4 col-form-label text-md-right">返回时高度（米）</label>

                        <div class="col-md-6">
                            <input id="return-height" type="text" class="form-control"
                                   value="{{ $area->parameters["return_height"] }}" disabled>
                        </div>
                    </div>

                </form>

            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col">
                <form method="POST" action="{{ route('records.store') }}" aria-label="指派任务">
                    @csrf

                    <div class="form-group row">
                        <label for="device" class="col-md-4 col-form-label text-md-right">执飞设备</label>
                        <div class="col-md-6">
                            <select class="form-control{{ $errors->has('device_id') ? ' is-invalid' : '' }}" id="device"
                                    name="device_id">
                                <option value="0">---</option>
                                @foreach($devices as $device)
                                    <option value="{{ $device->id }}" {{ old('device_id') == $device->id ? 'selected' : '' }}>{{ $device->name }}（{{ $device->model->name }}）</option>
                                @endforeach
                            </select>

                            @if ($errors->has('device_id'))
                                <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('device_id') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="action" class="col-md-4 col-form-label text-md-right">任务</label>
                        <div class="col-md-6">
                            <select class="form-control{{ $errors->has('action_id') ? ' is-invalid' : '' }}" id="action"
                                    name="action_id">
                                <option value="0">---</option>
                                @foreach($actions as $action)
                                    <option value="{{ $action->id }}" {{ old('action_id') == $action->id ? 'selected' : '' }}>{{ $action->name }}</option>
                                @endforeach
                            </select>

                            @if ($errors->has('action_id'))
                                <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('action_id') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>

                    <input type="hidden" name="area_id" value="{{ $area->id }}">

                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-info">
                                指派
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    @endcomponent
    <div class="modal fade" id="delete-area-modal" tabindex="-1" role="dialog"
         aria-labelledby="delete-area-modal-label"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="delete-area-modal-label">删除确认</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="关闭">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <tr>
                                <td>ID</td>
                                <td><code>{{ $area->id }}</code></td>
                            </tr>
                            <tr>
                                <td>名称</td>
                                <td><span>{{ $area->name }}</span></td>
                            </tr>
                            <tr>
                                <td>面积</td>
                                <td><samp>{{ $area->parameters["size"] }} ㎡</samp></td>
                            </tr>
                        </table>
                    </div>
                    @alert(['type'=>'danger'])
                    删除之后，此区域的任务记录也将全部删除。
                    @endalert
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <a role="button" href="{{ route('areas.destroy', $area->id) }}" class="btn btn-danger"
                       onclick="event.preventDefault();
                                document.getElementById('delete-form').submit();">
                        删除
                    </a>
                    <form id="delete-form" action="#" method="POST" style="display: none;">
                        @csrf
                        @method('DELETE')
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra_css')
    <style>
        #map {
            height: 60vh;
            width: 100%;
        }

        .calculation-box {
            height: 75px;
            width: 150px;
            position: absolute;
            bottom: 40px;
            left: 10px;
            background-color: rgba(255, 255, 255, .9);
            padding: 15px;
            text-align: center;
        }
    </style>
@endsection

@section('extra_js')
    <script>
        // set range sliders
        $("#min-height").ionRangeSlider({
            type: "single",
            min: 0,
            max: 100,
            disable: true
        });
        $("#max-height").ionRangeSlider({
            type: "single",
            min: 20,
            max: 500,
            disable: true
        });
        $("#return-height").ionRangeSlider({
            type: "single",
            min: 20,
            max: 500,
            disable: true
        });

        // set map
        mapboxgl.accessToken = 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4M29iazA2Z2gycXA4N2pmbDZmangifQ.-g_vE53SD2WrJ6tFX7QHmA';
        var map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/satellite-streets-v10',
            center: @json($area->parameters["center"]),
            zoom: 16
        });
        map.addControl(new mapboxgl.GeolocateControl({
            positionOptions: {
                enableHighAccuracy: true
            },
            trackUserLocation: true
        }));
        map.addControl(new MapboxLanguage({
            defaultLanguage: 'zh'
        }));

        var draw = new MapboxDraw({
            displayControlsDefault: false
        });
        map.addControl(draw);

        PATH = "{{ base64_encode($area->path) }}";
        draw.add(JSON.parse(atob(PATH)));

    </script>
@endsection

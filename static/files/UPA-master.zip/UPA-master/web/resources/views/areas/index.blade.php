@extends('layouts.app')

@section('page_title')
    巡航区域 - @parent
@endsection

@section('content')
    @component('components.jumbo')
        @slot('title')
            巡航区域
            <small>
                <a class="btn btn-outline-primary mb-2 ml-3" href="{{ route('areas.create') }}">
                    创建区域
                </a>
            </small>
        @endslot
        @if (session('success'))
            @alert(['type'=>'success'])
            {{ session('success') }}
            @endalert
        @endif
        @if (session('error'))
            @alert(['type'=>'danger'])
            {{ session('error') }}
            @endalert
        @endif
        @include('components.errors')
        <div class="row">
            <div class="col">
                <div class="d-flex flex-wrap justify-content-around">
                    @foreach($areas as $area)
                        <a class="m-2" href="{{ route('areas.show', $area->id) }}">
                            <div class="card app-card text-white app-problem-card {{ empty($area->background_image) ? 'app-card-mask' : '' }}"
                                 @empty($area->background_image)
                                 style="background-color: {{ $area->color }}"
                                    @endempty
                            >
                                @isset($area->background_image)
                                    <img class="app-card-img card-img app-img" src="{{ $area->background_image }}">
                                @endisset
                                <div class="card-img-overlay app-problem-card-img-overlay">
                                    <table class="app-card-table" style="height: 100%;width:  100%;">
                                        <tbody>
                                        <tr>
                                            <td class="align-middle">
                                                <h4>{{ $area->name }}</h4>
                                                <hr>
                                                <div class="d-flex justify-content-around">
                                                    <span>
                                                        <ion-icon name="cellular"></ion-icon>
                                                        {{ $area->parameters["size"] }} ㎡
                                                    </span>
                                                    <span>
                                                        <ion-icon name="crop"></ion-icon>
                                                        {{ $area->parameters["min_height"] }} /
                                                        {{ $area->parameters["max_height"] }} /
                                                        {{ $area->parameters["return_height"] }}
                                                    </span>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </a>
                    @endforeach
                </div>
            </div>
        </div>
    @endcomponent
@endsection

@section('extra_js')
    <script>
        $(".app-problem-card-img-overlay").hover(
            function () {
                $(this).prev().addClass("app-card-img-hover");
            },
            function () {
                $(this).prev().removeClass("app-card-img-hover");
            }
        );
    </script>
@endsection

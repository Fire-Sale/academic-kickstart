@extends('layouts.app')

@section('page_title')
    新建区域 - @parent
@endsection

@section('content')
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card">
                <div class="card-header">巡航区域</div>

                <div class="card-body">
                    <form method="POST" id="form" action="{{ route('areas.store') }}" aria-label="新建区域">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">名称</label>

                            <div class="col-md-6">
                                <input id="name" type="text"
                                       class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
                                       name="name" value="{{ old('name') }}" required autofocus>
                                <small class="form-text text-muted">
                                    长度不超过 16 位。
                                </small>

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <hr>

                        <div class="form-group row">
                            <label for="map" class="col-md-2 col-form-label text-md-right">地图区域</label>

                            <div class="col-md-9">
                                <div id='map'></div>
                                <div class='calculation-box'>
                                    <p class="mb-0">所选面积 (㎡)</p>
                                    <div id='calculated-area'></div>
                                </div>
                                @if ($errors->has('path'))
                                    <span class="invalid-feedback" role="alert" style="display: inline !important;">
                                        <strong>{{ $errors->first('path') }}</strong>
                                    </span>
                                @endif
                                @if ($errors->has('center'))
                                    <span class="invalid-feedback" role="alert" style="display: inline !important;">
                                        <strong>{{ $errors->first('center') }}</strong>
                                    </span>
                                @endif
                                @if ($errors->has('size'))
                                    <span class="invalid-feedback" role="alert" style="display: inline !important;">
                                        <strong>{{ $errors->first('size') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <input type="hidden" id="path" name="path" value="/">
                        <input type="hidden" id="size" name="size" value="0">
                        <input type="hidden" id="center" name="center" value="/">

                        <hr>

                        <div class="form-group row">
                            <label for="area-type-urban" class="col-md-4 col-form-label text-md-right pt-0">地区</label>

                            <div class="col-md-6">
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" id="area-type-urban" name="area_type" class="custom-control-input"
                                           value="urban" required{{ old('area_type') == 'urban' ? ' checked' : ''}}>
                                    <label class="custom-control-label" for="area-type-urban">城市</label>
                                </div>
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" id="area-type-rural" name="area_type" class="custom-control-input"
                                           value="rural"{{ old('area_type') == 'rural' ? ' checked' : ''}}>
                                    <label class="custom-control-label" for="area-type-rural">乡村</label>
                                </div>

                                @if ($errors->has('area_type'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('area_type') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="min-height" class="col-md-4 col-form-label text-md-right">最小高度（米）</label>

                            <div class="col-md-6">
                                <input id="min-height" type="text"
                                       class="form-control{{ $errors->has('min_height') ? ' is-invalid' : '' }}"
                                       name="min_height" value="{{ old('min_height') }}" required>

                                @if ($errors->has('min_height'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('min_height') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="max-height" class="col-md-4 col-form-label text-md-right">最大高度（米）</label>

                            <div class="col-md-6">
                                <input id="max-height" type="text"
                                       class="form-control{{ $errors->has('max_height') ? ' is-invalid' : '' }}"
                                       name="max_height" value="{{ old('max_height') }}" required>

                                @if ($errors->has('max_height'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('max_height') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="return-height" class="col-md-4 col-form-label text-md-right">返回时高度（米）</label>

                            <div class="col-md-6">
                                <input id="return-height" type="text"
                                       class="form-control{{ $errors->has('return_height') ? ' is-invalid' : '' }}"
                                       name="return_height" value="{{ old('return_height') }}" required>

                                @if ($errors->has('return_height'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('return_height') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-info"
                                        onclick="$('#path').val(JSON.stringify(draw.getAll()));$('#center').val(JSON.stringify(map.getCenter()));">
                                    保存
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('extra_css')
    <style>
        #map { height: 60vh; width:100%; }
        .calculation-box {
            height: 75px;
            width: 150px;
            position: absolute;
            bottom: 40px;
            left: 10px;
            background-color: rgba(255, 255, 255, .9);
            padding: 15px;
            text-align: center;
        }
    </style>
@endsection

@section('extra_js')
    <script>
        // set range sliders
        $("#min-height").ionRangeSlider({
            type: "single",
            min: 0,
            max: 100,
            from: 20
        });
        $("#max-height").ionRangeSlider({
            type: "single",
            min: 20,
            max: 500,
            from: 130
        });
        $("#return-height").ionRangeSlider({
            type: "single",
            min: 20,
            max: 500,
            from: 50
        });

        // set map
        mapboxgl.accessToken = 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4M29iazA2Z2gycXA4N2pmbDZmangifQ.-g_vE53SD2WrJ6tFX7QHmA';
        var map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/satellite-streets-v10',
            center: [116.3911, 39.907],
            zoom: 16
        });
        map.addControl(new mapboxgl.GeolocateControl({
            positionOptions: {
                enableHighAccuracy: true
            },
            trackUserLocation: true
        }));
        map.addControl(new MapboxLanguage({
            defaultLanguage: 'zh'
        }));

        var draw = new MapboxDraw({
            displayControlsDefault: false,
            controls: {
                polygon: true,
                trash: true
            }
        });
        map.addControl(draw);

        map.on('draw.create', updateArea);
        map.on('draw.delete', updateArea);
        map.on('draw.update', updateArea);

        function updateArea(e) {
            var data = draw.getAll();
            var answer = document.getElementById('calculated-area');
            if (data.features.length > 0) {
                var area = turf.area(data);
                // restrict to area to 2 decimal points
                var rounded_area = Math.round(area*100)/100;
                answer.innerHTML = '<p><strong>' + rounded_area + '</strong></p>';
                $("#size").val(rounded_area);
            } else {
                answer.innerHTML = '';
            }
        }
        navigator.geolocation.getCurrentPosition(
            function (position) {
                map.jumpTo({center: [position.coords.longitude, position.coords.latitude]});
            },
            function (e) {
                var msg = e.code;
                var dd = e.message;
                console.log(msg);
                console.log(dd);
            }
        )
    </script>
@endsection

@extends('layouts.app')

@section('page_title')
    任务详情 - @parent
@endsection

@section('content')
    @component('components.jumbo-detail')
        @slot('title')
            任务详情
            <small>
                <span class="badge badge-info">
                    <ion-icon name="locate"></ion-icon>
                    {{ $record->area->name }}
                </span>
                <span class="badge badge-info">
                    <ion-icon name="paper-plane"></ion-icon>
                    {{ $record->device->name }}
                </span>
                <span class="badge badge-primary">
                    <ion-icon name="analytics"></ion-icon>
                    {{ $record->action->name }}
                </span>
                @if($record->status == "pending")
                    <span class="badge badge-secondary">
                        <ion-icon name="help"></ion-icon>
                        等待中
                    </span>
                @elseif($record->status == "operating")
                    <span class="badge badge-primary">
                        <ion-icon name="jet"></ion-icon>
                        执行中
                    </span>
                @elseif($record->status == "successful")
                    <span class="badge badge-success">
                        <ion-icon name="checkmark-circle"></ion-icon>
                        成功
                    </span>
                @elseif($record->status == "failed")
                    <span class="badge badge-danger">
                        <ion-icon name="close-circle"></ion-icon>
                        失败
                    </span>
                @endif
            </small>
        @endslot
        @if (session('success'))
            @alert(['type'=>'success'])
            {{ session('success') }}
            @endalert
        @endif
        @if (session('error'))
            @alert(['type'=>'danger'])
            {{ session('error') }}
            @endalert
        @endif
        @include('components.errors')
        <div class="row">
            <div class="col">
                <div id='map'></div>
                <div class='calculation-box'>
                    <p class="mb-0">所选面积 (㎡)</p>
                    <div id='calculated-area'><b>{{ $record->area->parameters["size"] }}</b></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <form class="mt-4">
                    <div class="form-group row">
                        <label for="area-type-urban" class="col-md-4 col-form-label text-md-right pt-0">地区</label>

                        <div class="col-md-6">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="area-type-urban" class="custom-control-input"
                                       value="urban" required
                                       {{ $record->area->parameters["area_type"] == 'urban' ? ' checked' : ''}} disabled>
                                <label class="custom-control-label" for="area-type-urban">城市</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="area-type-rural" class="custom-control-input"
                                       value="rural"
                                       {{ $record->area->parameters["area_type"] == 'rural' ? 'checked' : ''}} disabled>
                                <label class="custom-control-label" for="area-type-rural">乡村</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="min-height" class="col-md-4 col-form-label text-md-right">最小高度（米）</label>

                        <div class="col-md-6">
                            <input id="min-height" type="text" class="form-control"
                                   value="{{ $record->area->parameters['min_height'] }}" disabled>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="max-height" class="col-md-4 col-form-label text-md-right">最大高度（米）</label>

                        <div class="col-md-6">
                            <input id="max-height" type="text" class="form-control"
                                   value="{{ $record->area->parameters["max_height"] }}" disabled>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="return-height" class="col-md-4 col-form-label text-md-right">返回时高度（米）</label>

                        <div class="col-md-6">
                            <input id="return-height" type="text" class="form-control"
                                   value="{{ $record->area->parameters["return_height"] }}" disabled>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    @endcomponent
@endsection

@section('extra_css')
    <style>
        #map {
            height: 60vh;
            width: 100%;
        }

        .calculation-box {
            height: 75px;
            width: 150px;
            position: absolute;
            bottom: 40px;
            left: 10px;
            background-color: rgba(255, 255, 255, .9);
            padding: 15px;
            text-align: center;
        }

        .marker {
            display: block;
            cursor: pointer;
            padding: 0;
            transition-duration: 0s;
            background-size: contain;
        }
    </style>
@endsection

@section('extra_js')
    <script>
        // set range sliders
        $("#min-height").ionRangeSlider({
            type: "single",
            min: 0,
            max: 100,
            disable: true
        });
        $("#max-height").ionRangeSlider({
            type: "single",
            min: 20,
            max: 500,
            disable: true
        });
        $("#return-height").ionRangeSlider({
            type: "single",
            min: 20,
            max: 500,
            disable: true
        });

        // set map
        mapboxgl.accessToken = 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4M29iazA2Z2gycXA4N2pmbDZmangifQ.-g_vE53SD2WrJ6tFX7QHmA';
        var map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/satellite-streets-v10',
            center: @json($record->area->parameters["center"]),
            zoom: 16
        });
        map.addControl(new mapboxgl.GeolocateControl({
            positionOptions: {
                enableHighAccuracy: true
            },
            trackUserLocation: true
        }));
        map.addControl(new MapboxLanguage({
            defaultLanguage: 'zh'
        }));

        // set draw
        MapboxDraw.modes["simple_select"].onClick = null;
        let draw = new MapboxDraw({
            displayControlsDefault: false
        });
        map.addControl(draw);

        PATH = "{{ base64_encode($record->area->path) }}";
        draw.add(JSON.parse(atob(PATH)));

        @isset($record->detail["js"])
            {!! $record->detail["js"] !!}
        @endisset

    </script>
@endsection

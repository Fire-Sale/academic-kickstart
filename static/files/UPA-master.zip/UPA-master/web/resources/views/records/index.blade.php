@extends('layouts.app')

@section('page_title')
    任务记录 - @parent
@endsection

@section('content')
    @component('components.jumbo')
        @slot('title')
            任务记录
        @endslot
        @if (session('success'))
            @alert(['type'=>'success'])
            {{ session('success') }}
            @endalert
        @endif
        @if (session('error'))
            @alert(['type'=>'danger'])
            {{ session('error') }}
            @endalert
        @endif
        @include('components.errors')
        <div class="row">
            <div class="col">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">执飞设备</th>
                            <th scope="col">区域</th>
                            <th scope="col">任务</th>
                            <th scope="col">指派时间</th>
                            <th scope="col">状态</th>
                            <th scope="col">操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach ($records as $record)
                            <tr>
                                <th scope="row" class="text-nowrap">{{ $record->id }}</th>
                                <td class="text-nowrap">{{ $record->device->name }}（{{ $record->device->model->name }}）</td>
                                <td><a href="{{ route('areas.show', $record->area->id) }}">{{ $record->area->name }}</a></td>
                                <td>{{ $record->action->name }}</td>
                                <td><samp>{{ $record->created_at }}</samp></td>
                                <td>
                                    @if($record->status == "pending")
                                        <span class="badge badge-secondary">等待中</span>
                                    @elseif($record->status == "operating")
                                        <span class="badge badge-primary">执行中</span>
                                    @elseif($record->status == "successful")
                                        <span class="badge badge-success">成功</span>
                                    @elseif($record->status == "failed")
                                        <span class="badge badge-danger">失败</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a class="btn btn-outline-info" role="button" href="{{ route('records.show', $record->id) }}">查看</a>
                                        <button type="button" class="btn btn-outline-danger" data-toggle="modal"
                                                data-target="#delete-record-modal" data-id="{{ $record->id }}"
                                                data-area="{{ $record->area->name }}" data-device="{{ $record->device->name }}（{{ $record->device->model->name }}）"
                                                data-time="{{ $record->created_at }}">
                                            删除
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @endcomponent
    <div class="modal fade" id="delete-record-modal" tabindex="-1" role="dialog"
         aria-labelledby="delete-record-modal-label"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="delete-record-modal-label">删除确认</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="关闭">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <tr>
                                <td>ID</td>
                                <td><code id="record-id"></code></td>
                            </tr>
                            <tr>
                                <td>区域</td>
                                <td><span id="record-area"></span></td>
                            </tr>
                            <tr>
                                <td>执飞设备</td>
                                <td><span id="record-device"></span></td>
                            </tr>
                            <tr>
                                <td>指派时间</td>
                                <td><code id="record-time"></code></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <a role="button" href="#" class="btn btn-danger"
                       onclick="event.preventDefault();
                                document.getElementById('delete-form').submit();">
                        删除
                    </a>
                    <form id="delete-form" action="#" method="POST" style="display: none;">
                        @csrf
                        @method('DELETE')
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra_js')
    <script>
        $("#delete-record-modal").on("show.bs.modal", function (event) {
            let button = $(event.relatedTarget);
            let id = button.data("id");
            let modal = $(this);
            modal.find("#record-id").text(id);
            modal.find("#record-area").text(button.data("area"));
            modal.find("#record-device").text(button.data("device"));
            modal.find("#record-time").text(button.data("time"));
            modal.find("#delete-form").attr("action", "records/" + id);
        });
    </script>
@endsection

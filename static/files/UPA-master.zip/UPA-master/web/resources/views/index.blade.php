@extends('layouts.app')

@section('content')
    @component('components.jumbo')
        @slot('title', config('app.name'))
        @slot('introduction', '无人机精准农业')

        <div class="row m-1">
            <div class="col-md-6 pr-3 mb-2">
                <a href="{{ route('areas.index') }}">
                    <div class="card app-card text-white">
                        <img class="app-card-img card-img app-img" src="{{ url('img/area.jpg') }}"
                             alt="巡航">
                        <div class="card-img-overlay app-card-img-overlay">
                            <table class="app-card-table" style="height: 100%;width:  100%;">
                                <tbody>
                                <tr>
                                    <td class="align-middle">
                                        <h1>
                                            <small>
                                                <ion-icon name="filing"></ion-icon>
                                            </small>
                                            巡航
                                        </h1>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            <div class="app-card-detail" style="display: none">
                                <p>已部署 {{ $device_count }} 片区域</p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6 pl-3 mb-2">
                <a href="{{ route('devices.index') }}">
                    <div class="card text-white app-card">
                        <img class="app-card-img card-img app-img" src="{{ url('img/device.jpg') }}"
                             alt="设备">
                        <div class="card-img-overlay app-card-img-overlay">
                            <table class="app-card-table" style="height: 100%;width:  100%;">
                                <tbody>
                                <tr>
                                    <td class="align-middle">
                                        <h1>
                                            <small>
                                                <ion-icon name="paper-plane"></ion-icon>
                                            </small>
                                            设备
                                        </h1>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            <div class="app-card-detail" style="display: none">
                                <p>已关联 {{ $device_count }} 架无人机</p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    @endcomponent
@endsection

@section('extra_js')
    <script>
        $(".app-card-img-overlay").hover(
            function () {
                $(this).prev().addClass("app-card-img-hover");
                $(this).children("table").css("height", "70%");
                $(this).children(".app-card-detail").show();
            },
            function () {
                $(this).prev().removeClass("app-card-img-hover");
                $(this).children("table").css("height", "100%");
                $(this).children(".app-card-detail").hide();
            }
        );
    </script>
@endsection
@extends('layouts.app')

@section('page_title')
    设备管理 - @parent
@endsection

@section('content')
    @component('components.jumbo')
        @slot('title')
            设备管理
            <small>
                <a class="btn btn-outline-primary mb-2 ml-3" href="{{ route('devices.create') }}">
                    关联设备
                </a>
            </small>
        @endslot
        @if (session('success'))
            @alert(['type'=>'success'])
            {{ session('success') }}
            @endalert
        @endif
        @if (session('error'))
            @alert(['type'=>'danger'])
            {{ session('error') }}
            @endalert
        @endif
        @include('components.errors')
        <div class="row">
            <div class="col">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">名称</th>
                            <th scope="col">机型</th>
                            <th scope="col">序列号</th>
                            <th scope="col">操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach ($devices as $key => $device)
                            <tr>
                                <th scope="row" class="text-nowrap">{{ $device->id }}</th>
                                <td class="text-nowrap">{{ $device->name }}</td>
                                <td><samp>{{ $device->model->name }}</samp></td>
                                <td><code>{{ $device->sn }}</code></td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <button type="button" class="btn btn-outline-danger" data-toggle="modal"
                                                data-target="#delete-device-modal" data-id="{{ $device->id }}"
                                                data-name="{{ $device->name }}" data-model="{{ $device->model->name }}"
                                                data-sn="{{ $device->sn }}">
                                            删除
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @endcomponent
    <div class="modal fade" id="delete-device-modal" tabindex="-1" role="dialog"
         aria-labelledby="delete-device-modal-label"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="delete-device-modal-label">删除确认</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="关闭">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <tr>
                                <td>ID</td>
                                <td><code id="device-id"></code></td>
                            </tr>
                            <tr>
                                <td>名称</td>
                                <td><span id="device-name"></span></td>
                            </tr>
                            <tr>
                                <td>机型</td>
                                <td><samp id="device-model"></samp></td>
                            </tr>
                            <tr>
                                <td>序列号</td>
                                <td><code id="device-sn"></code></td>
                            </tr>
                        </table>
                    </div>
                    @alert(['type'=>'danger'])
                    删除之后，此设备的任务记录也将全部删除。
                    @endalert
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <a role="button" href="#" class="btn btn-danger"
                       onclick="event.preventDefault();
                                document.getElementById('delete-form').submit();">
                        删除
                    </a>
                    <form id="delete-form" action="#" method="POST" style="display: none;">
                        @csrf
                        @method('DELETE')
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra_js')
    <script>
        $("#delete-device-modal").on("show.bs.modal", function (event) {
            let button = $(event.relatedTarget);
            let id = button.data("id");
            let modal = $(this);
            modal.find("#device-id").text(id);
            modal.find("#device-name").text(button.data("name"));
            modal.find("#device-model").text(button.data("model"));
            modal.find("#device-sn").text(button.data("sn"));
            modal.find("#delete-form").attr("action", "devices/" + id);
        });
    </script>
@endsection

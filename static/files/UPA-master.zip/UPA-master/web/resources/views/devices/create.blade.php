@extends('layouts.app')

@section('page_title')
    关联设备 - @parent
@endsection

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">关联设备</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('devices.store') }}" aria-label="关联设备">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">名称</label>

                            <div class="col-md-6">
                                <input id="name" type="text"
                                       class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
                                       name="name" value="{{ old('name') }}" required autofocus>
                                <small class="form-text text-muted">
                                    长度不超过 16 位。
                                </small>

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="model" class="col-md-4 col-form-label text-md-right">机型</label>
                            <div class="col-md-6">
                                <select class="form-control{{ $errors->has('model') ? ' is-invalid' : '' }}" id="model" name="model">
                                    <option value="0">---</option>
                                    @foreach($models as $model)
                                        <option value="{{ $model->id }}" {{ old('model') == $model->id ? 'selected' : '' }}>{{ $model->name }}</option>
                                    @endforeach
                                </select>

                                @if ($errors->has('model'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('model') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="sn" class="col-md-4 col-form-label text-md-right">序列号</label>

                            <div class="col-md-6">
                                <input id="sn" type="text"
                                       class="form-control{{ $errors->has('sn') ? ' is-invalid' : '' }}"
                                       name="sn" value="{{ old('sn') }}">

                                @if ($errors->has('sn'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('sn') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <hr>

                        <div class="form-group row">
                            <label for="secret" class="col-md-4 col-form-label text-md-right">配对码</label>

                            <div class="col-md-6">
                                <input id="secret" type="text" placeholder="Te5tc0d6"
                                       class="form-control{{ $errors->has('secret') ? ' is-invalid' : '' }}"
                                       name="secret" value="{{ old('secret') }}">

                                @if ($errors->has('secret'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('secret') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-info">
                                    配对
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

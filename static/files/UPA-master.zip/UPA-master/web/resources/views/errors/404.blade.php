@extends('layouts.app')

@section('page_title')
    出错 - @parent
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">HTTP 404</div>
                    <div class="card-body">
                        <p>此页面不存在，请查证后再试。</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

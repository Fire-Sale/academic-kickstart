@extends('layouts.app')

@section('page_title')
    编辑资料 - @parent
@endsection

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">编辑用户资料</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('users.update', $user) }}" aria-label="编辑用户">
                        @csrf
                        @method('PATCH')

                        <div class="form-group row">
                            <label for="username" class="col-md-4 col-form-label text-md-right">用户名</label>

                            <div class="col-md-6">
                                <input id="username" type="text"
                                       class="form-control{{ $errors->has('username') ? ' is-invalid' : '' }}"
                                       name="username" value="{{ $user->username }}" required autofocus>

                                @if ($errors->has('username'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('username') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">邮箱地址</label>

                            <div class="col-md-6">
                                <input id="email" type="email"
                                       class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"
                                       name="email" value="{{ $user->email }}" required>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="qq" class="col-md-4 col-form-label text-md-right">QQ</label>

                            <div class="col-md-6">
                                <input id="qq" type="text"
                                       class="form-control{{ $errors->has('qq') ? ' is-invalid' : '' }}"
                                       name="qq" value="{{ $user->qq }}" required>

                                @if ($errors->has('qq'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('qq') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="phone" class="col-md-4 col-form-label text-md-right">手机号</label>

                            <div class="col-md-6">
                                <input id="phone" type="text"
                                       class="form-control{{ $errors->has('phone') ? ' is-invalid' : '' }}"
                                       name="phone" value="{{ $user->phone }}" required>
                                <small id="phone-help" class="form-text text-muted">
                                    QQ 与手机号为面试通知的重要依据，请务必如实填写。
                                </small>

                                @if ($errors->has('phone'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('phone') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">密码</label>

                            <div class="col-md-6">
                                <input id="password" type="password" name="password"
                                       class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}">

                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirmation" class="col-md-4 col-form-label text-md-right">确认密码</label>

                            <div class="col-md-6">
                                <input id="password-confirmation" type="password" name="password_confirmation"
                                       class="form-control{{ $errors->has('password_confirmation') ? ' is-invalid' : '' }}">
                                <small id="invitation-code-help" class="form-text text-muted">
                                    如果不修改密码，请留空。
                                </small>

                                @if ($errors->has('password_confirmation'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    编辑
                                </button>
                                <a role="button" class="btn btn-secondary" href="{{ route("users.show", $user->id) }}">
                                    返回
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

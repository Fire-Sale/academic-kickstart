@extends('layouts.app')

@section('content')
    @component('components.jumbo')
        @slot('title', config('app.name'))
        @slot('introduction')
            {{ config('settings.slogan') }}
            <a href="{{ route('about') }}">关于我们</a>
        @endslot

        <div class="row m-1">
            <div class="col-md-6 pr-3 mb-2">
                <a href="{{ route('problems.index') }}">
                    <div class="card app-card text-white">
                        <img class="app-card-img card-img app-img" src="{{ url('img/problems.jpg') }}"
                             alt="题库">
                        <div class="card-img-overlay app-card-img-overlay">
                            <table class="app-card-table" style="height: 100%;width:  100%;">
                                <tbody>
                                <tr>
                                    <td class="align-middle">
                                        <h1>
                                            <small>
                                                <ion-icon name="filing"></ion-icon>
                                            </small>
                                            题库
                                        </h1>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            <div class="app-card-detail" style="display: none">
                                <p>已有 {{ $problem_count }} 道题目等你挑战</p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6 pl-3 mb-2">
                <a href="{{ route('ranking') }}">
                    <div class="card text-white app-card">
                        <img class="app-card-img card-img app-img" src="{{ url('img/ranking.jpg') }}"
                             alt="排行榜">
                        <div class="card-img-overlay app-card-img-overlay">
                            <table class="app-card-table" style="height: 100%;width:  100%;">
                                <tbody>
                                <tr>
                                    <td class="align-middle">
                                        <h1>
                                            <small>
                                                <ion-icon name="list-box"></ion-icon>
                                            </small>
                                            排行榜
                                        </h1>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            <div class="app-card-detail" style="display: none">
                                <p>已有 {{ $user_count }} 名同学参与挑战</p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    @endcomponent
@endsection

@section('extra_js')
    <script>
        $(".app-card-img-overlay").hover(
            function () {
                $(this).prev().addClass("app-card-img-hover");
                $(this).children("table").css("height", "70%");
                $(this).children(".app-card-detail").show();
            },
            function () {
                $(this).prev().removeClass("app-card-img-hover");
                $(this).children("table").css("height", "100%");
                $(this).children(".app-card-detail").hide();
            }
        );
    </script>
@endsection
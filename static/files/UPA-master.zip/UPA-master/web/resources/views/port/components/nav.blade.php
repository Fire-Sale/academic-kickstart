<nav class="navbar navbar-light bg-light navbar-expand-lg">
    <div class="container">
        <img src="{{ url('img/flag.png') }}" class="img-fluid mr-2" style="max-height: 2.4rem;" id="logo">
        <a class="navbar-brand" href="{{ route('index') }}">{{ config('app.name') }}</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item {{ Request::is('/') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('index') }}">主页</a>
                </li>
                @if(config('settings.open_lib') || Auth::check())
                <li class="nav-item {{ Request::is('problems*') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('problems.index') }}">题库</a>
                </li>
                <li class="nav-item {{ Request::is('ranking*') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('ranking') }}">排行榜</a>
                </li>
                @endif
                @admin
                <li class="nav-item {{ Request::is('users*') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('users.index') }}">用户管理</a>
                </li>
                <li class="nav-item {{ Request::is('guests*') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('guests.index') }}">访客管理</a>
                </li>
                <li class="nav-item {{ Request::is('system*') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('system') }}">系统管理</a>
                </li>
                @endadmin
                <li class="nav-item {{ Request::is('about*') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('about') }}">关于</a>
                </li>

            </ul>

            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                @guest
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('login',
                            (Request::is("register*") || Request::is("login*")) && request()->input('callback') ?
                                ['callback' => request()->input('callback')] : []) }}">登录</a>
                    </li>
                    @if (config('settings.allow_register'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register',
                            (Request::is("register*") || Request::is("login*")) && request()->input('callback') ?
                                ['callback' => request()->input('callback')] : []) }}">注册</a>
                        </li>
                    @endif
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('guests.create') }}">访客申请</a>
                    </li>
                @else
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ Auth::user()->username }} <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" style="min-width: 0;" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item text-right" href="{{ route('users.show', Auth::user()) }}">
                                个人资料
                            </a>
                            <a class="dropdown-item text-right" href="{{ route('logout') }}"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                登出
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>
                        </div>
                    </li>
                @endguest
            </ul>
        </div>
    </div>
</nav>
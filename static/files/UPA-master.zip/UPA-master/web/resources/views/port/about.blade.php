@extends('layouts.app')

@section('page_title')
    关于 - @parent
@endsection

@section('content')
    @component('components.jumbo-detail')
        @slot('title', '关于我们')
        @slot('introduction', '')
        <div class="row">
            <div class="col" id="content">
                <div class="loader"></div>
            </div>
        </div>
        <div style="display: none">
            <textarea id="processor">{{ $content }}</textarea>
        </div>
    @endcomponent
@endsection

@section('extra_js')
    <script type="text/javascript">
        let editor = new mditor(document.getElementById("processor"));
        $("#content").html(editor.getHtml());
        $("#content a").attr("target", "_blank");
    </script>
@endsection

@extends('layouts.app')

@section('page_title')
    {{ $problem->title }} - @parent
@endsection

@section('content')
    @component('components.jumbo-detail')
        @slot('title')
            {{ $problem->title }}
            <small>
                by {{ $problem->user->username }}
            </small>
        @endslot
        @slot('introduction')
            <span class="badge badge-info">{{ $problem->problem_type->name }}</span>
            <span class="badge badge-primary">{{ $problem->get_decayed_score() }} 分</span>
            <span class="badge badge-secondary">{{ $problem->submitted }} 提交</span>
            <span class="badge badge-success">{{ $problem->solved }} 解出</span>
        @endslot
        @unless($problem->is_published)
            @alert(['type'=>'info'])
            这是一道未发布的题目。
            @endalert
        @endunless
        <div class="row">
            <div class="col">
                @can('update', $problem)
                    <a class="btn btn-outline-primary mb-2" role="button" href="{{ route('problems.edit', $problem->id) }}">
                        编辑题目
                    </a>
                    <button type="button" class="btn btn-outline-danger mb-2" data-toggle="modal"
                            data-target="#delete-modal">
                        删除题目
                    </button>
                @endcan
                @admin
                <a class="btn btn-outline-success mb-2" role="button" href="#"
                   onclick="event.preventDefault();document.getElementById('up-form').submit();">
                    顶!
                </a>
                <form id="up-form" action="{{ route('problems.up', $problem->id) }}" method="POST" style="display: none;">
                    @csrf
                </form>
                @endadmin
            </div>
        </div>
        <div class="row">
            <div class="col" id="content">
                <div class="loader"></div>
            </div>
        </div>
        <div style="display: none">
            <textarea id="processor">{{ $problem->content }}</textarea>
        </div>
        @isset($problem->attachment)
            <div class="row">
                <div class="col">
                    <a class="btn btn-secondary" role="button"
                       href="{{ config('filesystems.disks.ftp.url_prefix').$problem->attachment }}">下载附件</a>
                </div>
            </div>
        @endisset
        <hr>
        <div class="row">
            <div class="col-md-6">
                @if (session('success'))
                    @alert(['type'=>'success'])
                    {{ session('success') }}
                    @endalert
                @endif
                @if (session('error'))
                    @alert(['type'=>'danger'])
                    {{ session('error') }}
                    @endalert
                @endif
                @include('components.errors')
                @auth
                    @empty($approved_solution)
                        <form method="POST" action="{{ route('solutions.store', $problem->id) }}">
                            @csrf
                            <div class="form-row align-items-center">
                                @if($problem->is_py_needed)
                                    <div class="alert alert-info" role="alert">
                                        这是一道需要 py 的题！请在完成题中所述要求后，点击下方的申请按钮，然后寻找出题人给予分数。
                                    </div>
                                @else
                                    <div class="col-auto">
                                        <label class="sr-only" for="flag">Flag</label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <ion-icon name="flag"></ion-icon>
                                                </div>
                                            </div>
                                            <input type="text" class="form-control" id="flag" placeholder="Flag"
                                                   name="flag">
                                        </div>
                                    </div>
                                @endif
                                <div class="col-auto">
                                    <button type="submit" class="btn btn-primary mb-2">
                                        {{ $problem->is_py_needed ? '申请' : '提交' }}
                                    </button>
                                </div>
                            </div>
                        </form>
                    @else
                        <div class="alert alert-success" role="alert">
                            你已解出这道题，并且得到了 {{$approved_solution->score_ratio}}% 的分数。
                        </div>
                    @endif
                @else
                    <div class="alert alert-primary" role="alert">
                        <a href="{{ route('login') }}"><b>登录</b></a> 或 <a href="{{ route('register') }}"><b>注册</b></a>
                        后你才能进行提交等操作。
                    </div>
                @endauth
            </div>
        </div>
        @auth
            <hr>
            <div class="row">
                <div class="col">
                    <h1 class="mb-3">
                        @admin
                        所有用户提交记录
                        @else
                            提交记录
                            @endadmin
                            @unless($problem->is_py_needed)
                                <small>
                                    <a class="btn btn-outline-primary" href="#"
                                       role="button"
                                       onclick="event.preventDefault();$('.flag').toggleClass('hidden-flag')">
                                        显示 / 隐藏 flag
                                    </a>
                                </small>
                            @endunless
                    </h1>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">用户</th>
                                @unless($problem->is_py_needed)
                                    <th scope="col">Flag</th>
                                @endunless
                                <th scope="col">状态</th>
                                <th scope="col">提交时间</th>
                                @can('update', $problem)
                                    <th scope="col">操作</th>
                                @endcan
                            </tr>
                            </thead>
                            <tbody>
                            @foreach ($solutions as $solution)
                                <tr>
                                    <th scope="row" class="text-nowrap">{{ $solution->id }}</th>
                                    <th scope="row" class="text-nowrap">
                                        <a href="{{ route('users.show', $solution->user->id) }}">
                                            {{ $solution->user->username }}
                                        </a>
                                        @if($solution->user->is_admin)
                                            <span class="badge badge-primary">管理员</span>
                                        @endif
                                        @if($solution->user->is_guest)
                                            <span class="badge badge-secondary">访客</span>
                                        @endif
                                    </th>
                                    @unless($problem->is_py_needed)
                                        <td>
                                            <code class="text-nowrap">
                                        <span class="flag hidden-flag">
                                            {{ $solution->flag }}
                                        </span>
                                            </code>
                                        </td>
                                    @endunless
                                    <td>
                                        @if($solution->is_approved)
                                            <span class="badge badge-success">通过</span>
                                            <span class="badge badge-info">
                                                {{ $solution->approved_solution->score_ratio }}%
                                            </span>
                                        @else
                                            @if($solution->problem->is_py_needed)
                                                <span class="badge badge-secondary">审核中</span>
                                            @else
                                                <span class="badge badge-danger">错误</span>
                                            @endif
                                        @endif
                                    </td>
                                    <td><samp class="text-nowrap">{{ $solution->created_at }}</samp></td>
                                    @can('update', $problem)
                                        <td>
                                            @if($problem->is_py_needed)
                                                @if($solution->is_approved)
                                                    <a class="btn btn-outline-danger btn-sm" href="#"
                                                       onclick="event.preventDefault();
                                                               document.getElementById('disapprove-form-{{ $solution->id }}').submit();">
                                                        撤回批准
                                                    </a>
                                                    <form id="disapprove-form-{{ $solution->id }}"
                                                          action="{{ route('solutions.update', ['problem'=>$problem->id,'solution'=>$solution->id]) }}"
                                                          method="POST" style="display: none;">
                                                        @csrf
                                                        <input type="text" hidden name="approve" value="0">
                                                        @method('PATCH')
                                                    </form>
                                                @else
                                                    <a class="btn btn-outline-success btn-sm" href="#"
                                                       onclick="event.preventDefault();
                                                               document.getElementById('approve-form-{{ $solution->id }}').submit();">
                                                        批准
                                                    </a>
                                                    <form id="approve-form-{{ $solution->id }}"
                                                          action="{{ route('solutions.update', ['problem'=>$problem->id,'solution'=>$solution->id]) }}"
                                                          method="POST" style="display: none;">
                                                        @csrf
                                                        <input type="text" hidden name="approve" value="1">
                                                        @method('PATCH')
                                                    </form>
                                                @endif
                                            @endif
                                            @if($solution->is_approved)
                                                <button type="button" class="btn btn-outline-primary btn-sm"
                                                        data-toggle="modal"
                                                        data-target="#edit-solution-modal"
                                                        data-id="{{ $solution->id }}">
                                                    修改得分
                                                </button>
                                            @endif
                                            <a class="btn btn-outline-danger btn-sm" href="#"
                                               onclick="event.preventDefault();
                                                       document.getElementById('delete-form-{{ $solution->id }}').submit();">
                                                删除
                                            </a>
                                            <form id="delete-form-{{ $solution->id }}"
                                                  action="{{ route('solutions.destroy', ['problem'=>$problem->id,'solution'=>$solution->id]) }}"
                                                  method="POST" style="display: none;">
                                                @csrf
                                                @method('DELETE')
                                            </form>
                                        </td>
                                    @endcan
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endauth
    @endcomponent
    <div class="modal fade" id="edit-solution-modal" tabindex="-1" role="dialog"
         aria-labelledby="edit-solution-modal-label"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="edit-solution-modal-label">修改得分比例</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="关闭">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <tr>
                                <td>提交 ID</td>
                                <td><code id="solution-id"></code></td>
                            </tr>
                            <tr>
                                <td>用户 ID</td>
                                <td><code id="user-id"></code></td>
                            </tr>
                            <tr>
                                <td>用户名</td>
                                <td><span id="user-username"></span></td>
                            </tr>
                            <tr>
                                <td>邮箱</td>
                                <td><samp id="user-email"></samp></td>
                            </tr>
                            <tr>
                                <td>QQ</td>
                                <td><samp id="user-qq"></samp></td>
                            </tr>
                        </table>
                    </div>
                    <form id="edit-solution-form" method="POST" action="#" class="form-inline">
                        @method('PATCH')
                        @csrf
                        <div class="form-group row">
                            <div class="col">
                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">
                                                <code id="basic-score">{{ $problem->get_decayed_score() }}</code>
                                                *
                                            </div>
                                        </div>
                                        <input type="number" class="form-control" id="score-ratio"
                                               name="score_ratio" required>
                                        <div class="input-group-append">
                                            <div class="input-group-text">%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <a role="button" href="#" class="btn btn-primary"
                       onclick="event.preventDefault();
                                document.getElementById('edit-solution-form').submit();">
                        修改
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="delete-modal" tabindex="-1" role="dialog" aria-labelledby="delete-modal-label"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="delete-modal-label">删除确认</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="关闭">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <tr>
                                <td>ID</td>
                                <td><code>{{ $problem->id }}</code></td>
                            </tr>
                            <tr>
                                <td>标题</td>
                                <td>{{ $problem->title }}</td>
                            </tr>
                        </table>
                    </div>
                    @alert(['type'=>'danger'])
                    删除之后，此题目下的解题记录也将全部删除。
                    @endalert
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <a role="button" href="#" class="btn btn-danger"
                       onclick="event.preventDefault();
                                document.getElementById('delete-form').submit();">
                        删除
                    </a>
                    <form id="delete-form" action="{{ route('problems.destroy', $problem->id) }}" method="POST"
                          style="display: none;">
                        @csrf
                        @method('DELETE')
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra_js')
    <script type="text/javascript">
        let editor = new mditor(document.getElementById("processor"));
        $("#content").html(editor.getHtml());
        $("#content a").attr("target", "_blank");

        const SOLUTIONS = @json($approved_solutions);
        $("#edit-solution-modal").on("show.bs.modal", function (event) {
            let button = $(event.relatedTarget);
            let id = button.data("id");
            let modal = $(this);
            modal.find("#solution-id").text(SOLUTIONS[id].solution_id);
            modal.find("#user-id").text(SOLUTIONS[id].user_id);
            modal.find("#user-username").text(SOLUTIONS[id].username);
            modal.find("#user-email").text(SOLUTIONS[id].email);
            modal.find("#user-qq").text(SOLUTIONS[id].qq);
            modal.find("#score-ratio").val(SOLUTIONS[id].score_ratio);
            modal.find("#edit-solution-form").attr("action", "{{ $problem->id }}/solutions/" + SOLUTIONS[id].solution_id);
        });
    </script>
@endsection
@extends('layouts.app')

@section('page_title')
    注册 - @parent
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">注册</div>
                <div class="card-body">
                    <p>当前不允许新用户注册。</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

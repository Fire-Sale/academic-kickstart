<div class="jumbotron problem-jumbo">
    <h1 class="display-4">{{ $title }}</h1>
    <p class="lead">{{ $introduction }}</p>
    <hr class="mt-0 mb-4">
    {{ $slot }}
</div>
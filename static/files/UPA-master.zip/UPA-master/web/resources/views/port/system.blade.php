@extends('layouts.app')

@section('page_title')
    系统管理 - @parent
@endsection

@section('content')
    @component('components.jumbo')
        @slot('title', '系统管理')
        @slot('introduction', '管理系统配置与邀请码')

        <div class="row">
            <div class="col-md-6">
                @if (session('success'))
                    @alert(['type'=>'success'])
                    {{ session('success') }}
                    @endalert
                @endif
                @if (session('error'))
                    @alert(['type'=>'danger'])
                    {{ session('error') }}
                    @endalert
                @endif
                @include('components.errors')
            </div>
        </div>

        <h1>系统配置</h1>

        <div class="row mt-3">
            <div class="col-md-6">
                <form method="POST" action="{{ route('system') }}" aria-label="修改系统配置">
                    @csrf
                    @method('PUT')

                    <div class="form-group row">
                        <div class="col">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="allow-register"
                                       name="allow_register" {{ config('settings.allow_register') ? 'checked' : '' }}>
                                <label class="form-check-label" for="allow-register">开放注册</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="open-lib"
                                       name="open_lib" {{ config('settings.open_lib') ? 'checked' : '' }}>
                                <label class="form-check-label" for="open-lib">开放题库与排行榜</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="slogan" class="col col-form-label ml-1">首页标语</label>

                        <div class="col-lg-8">
                            <input id="slogan" type="text" class="form-control"
                                   name="slogan" value="{{ config('settings.slogan') }}">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="copyright" class="col col-form-label ml-1">页脚信息</label>

                        <div class="col-lg-8">
                            <input id="copyright" type="text" class="form-control"
                                   name="copyright" value="{{ config('settings.copyright') }}">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="show-top" class="col col-form-label ml-1">排行榜显示人数</label>

                        <div class="col-lg-8">
                            <input id="show-top" type="text" class="form-control"
                                   name="show_top" value="{{ config('settings.show_top') }}">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="start-time" class="col col-form-label ml-1">开始时间</label>

                        <div class="col-lg-8">
                            <input id="start-time" type="number" class="form-control"
                                   name="start_time" value="{{ config('settings.start_time') }}">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="end-time" class="col col-form-label ml-1">结束时间</label>

                        <div class="col-lg-8">
                            <input id="end-time" type="number" class="form-control"
                                   name="end_time" value="{{ config('settings.end_time') }}">
                            <small id="time-help" class="form-text text-muted">
                                均为 <strong>UTC+0</strong> 的 <strong>Unix 时间戳</strong>。
                            </small>
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col">
                            <button type="submit" class="btn btn-primary">
                                编辑
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>

        <hr>

        <h1>关于页面</h1>

        <form method="POST" action="{{ route('about') }}" aria-label="修改关于页面">
            @csrf
            @method('PATCH')
            <div class="form-group">
                <label for="content">正文</label>
                <textarea class="form-control" id="content" name="content" required>{{ old('content') ?? config("settings.about") }}</textarea>
            </div>
            <div class="form-group row mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-info">
                        编辑
                    </button>
                </div>
            </div>
        </form>

        <hr>

        <h1>
            邀请码
            <small>
                <a class="btn btn-outline-success" href="#" role="button"
                   onclick="event.preventDefault();document.getElementById('new-invitation-form').submit();">
                    新建邀请码
                </a>
            </small>
        </h1>

        <form id="new-invitation-form" action="{{ route('system.create_invitation') }}" method="POST" style="display: none;">
            @csrf
        </form>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th scope="col">邀请码</th>
                    <th scope="col">操作</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($invitations as $invitation)
                    <tr>
                        <td><code>{{ $invitation->code }}</code></td>
                        <td>
                            <a class="btn btn-outline-danger btn-sm" href="#"
                               onclick="event.preventDefault();document.getElementById('delete-form-{{ $invitation->code }}').submit();">
                                删除
                            </a>

                            <form id="delete-form-{{ $invitation->code }}"
                                  action="{{ route('system.delete_invitation', $invitation->code) }}"
                                  method="POST" style="display: none;">
                                @csrf
                                @method('DELETE')
                            </form>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>

        <hr>

        <h1>题目类别</h1>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">名称</th>
                    <th scope="col">操作</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($problem_types as $problem_type)
                    <tr>
                        <th>{{ $problem_type->id }}</th>
                        <td>
                            <form id="rename-form-{{ $problem_type->id }}"
                                  action="{{ route('system.rename_problem_type', $problem_type->id) }}"
                                  method="POST">
                                @csrf
                                @method('PATCH')
                                <div class="form-row align-items-center">
                                    <div class="col-auto">
                                        <label class="sr-only" for="name">名称</label>
                                        <input type="text" class="form-control mb-2 form-control-sm" id="name"
                                               name="name" required value="{{ $problem_type->name }}">
                                    </div>
                                </div>
                            </form>
                        </td>
                        <td>
                            <a class="btn btn-outline-primary btn-sm" href="#"
                               onclick="event.preventDefault();document.getElementById('rename-form-{{ $problem_type->id }}').submit();">
                                重命名
                            </a>
                            <a class="btn btn-outline-danger btn-sm" href="#" data-toggle="modal"
                               data-target="#delete-type-modal" data-id="{{ $problem_type->id }}"
                               data-name="{{ $problem_type->name }}">
                                删除
                            </a>
                        </td>
                    </tr>
                @endforeach
                <tr>
                    <th></th>
                    <td>
                        <form id="new-type-form"
                              action="{{ route('system.create_problem_type') }}"
                              method="POST">
                            @csrf
                            <div class="form-row align-items-center">
                                <div class="col-auto">
                                    <label class="sr-only" for="name">名称</label>
                                    <input type="text" class="form-control mb-2 form-control-sm" id="name"
                                           name="name" required placeholder="Moyu">
                                </div>
                            </div>
                        </form>
                    </td>
                    <td>
                        <a class="btn btn-outline-success btn-sm" href="#"
                           onclick="event.preventDefault();document.getElementById('new-type-form').submit();">
                            新建
                        </a>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    @endcomponent
    <div class="modal fade" id="delete-type-modal" tabindex="-1" role="dialog" aria-labelledby="delete-type-modal-label"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="delete-type-modal-label">删除确认</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="关闭">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <tr>
                                <td>类型 ID</td>
                                <td><code id="type-id"></code></td>
                            </tr>
                            <tr>
                                <td>名称</td>
                                <td><span id="type-name"></span></td>
                            </tr>
                        </table>
                    </div>
                    @alert(['type'=>'danger','title'=>'严重警告'])
                    删除之后，此类别的<b>题目</b>、<b>解题记录</b>也将全部删除。
                    @endalert
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <a role="button" href="#" class="btn btn-danger"
                       onclick="event.preventDefault();
                                document.getElementById('delete-form').submit();">
                        删除
                    </a>
                    <form id="delete-form" action="#" method="POST" style="display: none;">
                        @csrf
                        @method('DELETE')
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra_js')
    <script>
        $("#delete-type-modal").on("show.bs.modal", function (event) {
            let button = $(event.relatedTarget);
            let id = button.data("id");
            let name = button.data("name");
            let modal = $(this);
            modal.find("#type-id").text(id);
            modal.find("#type-name").text(name);
            modal.find("#delete-form").attr("action", "{{ route('system.create_problem_type') }}/" + id);
        });
    </script>
    <script type="text/javascript">
        var ele_textarea = document.getElementById('content');
        var editor = new mditor(ele_textarea);
    </script>
@endsection

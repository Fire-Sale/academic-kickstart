@extends('layouts.app')

@section('page_title')
    排行榜 - @parent
@endsection

@section('content')
    @component('components.jumbo')
        @slot('title')
            {{ Request::input('new') ? '新生排行榜' : '排行榜' }}
            <small>
                @if(Request::input('new'))
                    <a class="btn btn-outline-info mb-2" role="button" href="{{ url()->current() }}">转至总榜</a>
                @else
                    <a class="btn btn-outline-info mb-2" role="button" href="{{ url()->current() . '?new=1' }}">转至新生榜</a>
                @endif
            </small>
        @endslot
        <div class="row">
            <div class="col">
                <ul class="nav nav-pills justify-content-center mb-2">
                    <li class="nav-item">
                        <a class="nav-link {{ Request::is('ranking') ? 'active' : '' }}"
                           href="{{ route('ranking') . (Request::input('new') ? '?new=1' : '') }}">
                            所有方向
                        </a>
                    </li>
                    @foreach($types as $type)
                        <li class="nav-item">
                            <a class="nav-link {{ Request::is('ranking/'.$type->id) ? 'active' : '' }}"
                               href="{{ route('ranking', $type->id) . (Request::input('new') ? '?new=1' : '') }}">
                                {{ $type->name }}
                            </a>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">No.</th>
                            <th scope="col">ID</th>
                            <th scope="col">积分</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach ($users as $user)
                            <tr>
                                <th scope="row" class="text-nowrap">
                                    {{ $loop->iteration }}
                                    {{ $loop->iteration == 1 ? '🎉🎉🎉' : '' }}
                                    {{ $loop->iteration == 2 ? '🎉🎉' : '' }}
                                    {{ $loop->iteration == 3 ? '🎉' : '' }}
                                </th>
                                <td class="text-nowrap">
                                    <a href="{{ route('users.show', $user->id) }}">{{ $user->username }}</a>
                                </td>
                                <td><code class="text-nowrap">{{ round($user->total_score, 2) }}</code></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @endcomponent
@endsection

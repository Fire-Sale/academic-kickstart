@extends('layouts.app')

@section('page_title')
    访客管理 - @parent
@endsection

@section('content')
    @component('components.jumbo')
        @slot('title', '访客管理')
        @slot('introduction', '查看与管理访客申请')
        <div class="row">
            <div class="col">
                @if (session('success'))
                    @alert(['type'=>'success'])
                    {{ session('success') }}
                    @endalert
                @endif
                @if (session('error'))
                    @alert(['type'=>'danger'])
                    {{ session('error') }}
                    @endalert
                @endif
                @include('components.errors')

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">用户名</th>
                            <th scope="col">QQ</th>
                            <th scope="col">来自</th>
                            <th scope="col">申请理由</th>
                            <th scope="col">操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach ($applicants as $applicant)
                            <tr>
                                <th scope="row" class="text-nowrap">{{ $applicant['id'] }}</th>
                                <td class="text-nowrap">
                                    {{ $applicant['username'] }}
                                </td>
                                <td><samp>{{ $applicant['qq'] }}</samp></td>
                                <td>{{ $applicant['from'] }}</td>
                                <td>{{ $applicant['reason'] }}</td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        @if($applicant->is_approved)
                                            @if($applicant->user)
                                                <a class="btn btn-outline-info btn-sm"
                                                   href="{{ route('users.show', $applicant->user->id) }}">
                                                    查看用户
                                                </a>
                                            @else
                                                <a class="btn btn-outline-danger btn-sm disabled" href="#">
                                                    用户已删除
                                                </a>
                                            @endif
                                        @else
                                            <a class="btn btn-outline-success btn-sm" href="#"
                                               onclick="event.preventDefault();
                                                       document.getElementById('approve-form-{{ $applicant->id }}').submit();">
                                                通过申请
                                            </a>
                                            <form id="approve-form-{{ $applicant->id }}"
                                                  action="{{ route('guests.update', ['applicant'=>$applicant->id]) }}"
                                                  method="POST" style="display: none;">
                                                @csrf
                                                <input type="text" hidden name="approve" value="1">
                                                @method('PATCH')
                                            </form>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @endcomponent
@endsection

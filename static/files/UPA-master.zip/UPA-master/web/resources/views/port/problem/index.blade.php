@extends('layouts.app')

@section('page_title')
    题库 - @parent
@endsection

@section('content')
    @component('components.jumbo')
        @slot('title', '题库')
        <div class="row">
            <div class="col">
                <ul class="nav nav-pills justify-content-center mb-4">
                    <li class="nav-item">
                        <a class="nav-link {{ $current_type ? '' : 'active' }}"
                           href="{{ route('problems.index') }}">
                            所有类别
                        </a>
                    </li>
                    @foreach($types as $type)
                        <li class="nav-item">
                            <a class="nav-link {{ $current_type == $type->id ? 'active' : '' }}"
                               href="{{ route('problems.index') . '?type=' . $type->id }}">
                                {{ $type->name }}
                            </a>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
        @if (session('success'))
            @alert(['type'=>'success'])
            {{ session('success') }}
            @endalert
        @endif
        @if (session('error'))
            @alert(['type'=>'danger'])
            {{ session('error') }}
            @endalert
        @endif
        @include('components.errors')
        @can('create', App\Problem::class)
            <div class="row">
                <div class="col">
                    <a class="btn btn-outline-primary mb-2 ml-3" href="{{ route('problems.create') }}">
                        创建题目
                    </a>
                </div>
            </div>
        @endcan
        <div class="row">
            <div class="col">
                <div class="d-flex flex-wrap justify-content-around">
                    @foreach($problems as $problem)
                        <a class="m-2" href="{{ route('problems.show', $problem->id) }}">
                            <div class="card app-card text-white app-problem-card {{ empty($problem->background_image) ? 'app-card-mask' : '' }}"
                                 @empty($problem->background_image)
                                 style="background-color: {{ $problem->background_color }}"
                                    @endempty
                            >
                                @isset($problem->background_image)
                                    <img class="app-card-img card-img app-img" src="{{ $problem->background_image }}">
                                @endisset
                                <div class="card-img-overlay app-problem-card-img-overlay">
                                    <table class="app-card-table" style="height: 100%;width:  100%;">
                                        <tbody>
                                        <tr>
                                            <td class="align-middle">
                                                <h4>
                                                    @if(in_array($problem->id, $solved_problems))
                                                        <ion-icon class="text-success"
                                                                  name="checkmark-circle-outline"></ion-icon>
                                                    @endif
                                                    {{ $problem->title }}
                                                    @if(!$problem->is_published)
                                                        <span class="badge badge-secondary">草稿</span>
                                                    @endif
                                                </h4>
                                                <hr>
                                                <div class="d-flex justify-content-around">
                                                    <span>
                                                    <ion-icon name="pricetag"></ion-icon>
                                                        {{ $problem->problem_type->name }}
                                                    </span>
                                                    <span>
                                                    <ion-icon name="star"></ion-icon>
                                                        {{ $problem->get_decayed_score() }} 分
                                                    </span>
                                                    <span>
                                                    <ion-icon name="checkbox-outline"></ion-icon>
                                                        {{ $problem->solved }} / {{ $problem->submitted }}
                                                    </span>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </a>
                    @endforeach
                </div>
            </div>
        </div>
    @endcomponent
@endsection


@section('extra_js')
    <script>
        $(".app-problem-card-img-overlay").hover(
            function () {
                $(this).prev().addClass("app-card-img-hover");
            },
            function () {
                $(this).prev().removeClass("app-card-img-hover");
            }
        );
    </script>
@endsection

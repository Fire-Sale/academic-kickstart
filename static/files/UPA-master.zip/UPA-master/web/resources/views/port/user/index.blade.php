@extends('layouts.app')

@section('page_title')
    用户管理 - @parent
@endsection

@section('content')
    @component('components.jumbo')
        @slot('title', '用户管理')
        @slot('introduction', '查看或修改用户')
        <div class="row">
            <div class="col">
                @if (session('success'))
                    @alert(['type'=>'success'])
                    {{ session('success') }}
                    @endalert
                @endif
                @if (session('error'))
                    @alert(['type'=>'danger'])
                    {{ session('error') }}
                    @endalert
                @endif
                @include('components.errors')

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">用户名</th>
                            <th scope="col">邮箱</th>
                            <th scope="col">学号</th>
                            <th scope="col">积分</th>
                            <th scope="col">操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach ($users as $user)
                            <tr>
                                <th scope="row" class="text-nowrap">{{ $user['id'] }}</th>
                                <td class="text-nowrap">
                                    {{ $user['username'] }}
                                    @if($user['is_admin'])
                                        <span class="badge badge-primary">管理员</span>
                                    @endif
                                    @if($user['is_guest'])
                                        <span class="badge badge-secondary">访客</span>
                                    @endif
                                </td>
                                <td><samp>{{ $user['email'] }}</samp></td>
                                <td><samp class="text-nowrap">{{ $user['person_id'] }}</samp></td>
                                <td>
                                    <code class="text-nowrap">{{ round($user['total_score'], 2) }}</code>
                                    @if($user->curse_ratio != 100)
                                        <span class="badge badge-danger">诅咒：{{ $user->curse_ratio }}%</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a class="btn btn-outline-info"
                                           href="{{ route('users.show', $user['id']) }}" role="button">
                                            查看
                                        </a>
                                        <a class="btn btn-outline-primary"
                                           href="{{ route('users.edit', $user['id']) }}" role="button">
                                            编辑
                                        </a>
                                        <button type="button" class="btn btn-outline-dark" data-toggle="modal"
                                                data-target="#curse-user-modal" data-id="{{ $user['id'] }}">
                                            诅咒
                                        </button>
                                        <button type="button" class="btn btn-outline-danger" data-toggle="modal"
                                                data-target="#delete-user-modal" data-id="{{ $user['id'] }}">
                                            删除
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @endcomponent
    <div class="modal fade" id="delete-user-modal" tabindex="-1" role="dialog" aria-labelledby="delete-user-modal-label"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="delete-user-modal-label">删除确认</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="关闭">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <tr>
                                <td>用户 ID</td>
                                <td><code id="user-id"></code></td>
                            </tr>
                            <tr>
                                <td>用户名</td>
                                <td><span id="user-username"></span></td>
                            </tr>
                            <tr>
                                <td>邮箱</td>
                                <td><samp id="user-email"></samp></td>
                            </tr>
                            <tr>
                                <td>学号</td>
                                <td><samp id="user-person-id"></samp></td>
                            </tr>
                            <tr>
                                <td>积分</td>
                                <td><code id="user-total-score"></code></td>
                            </tr>
                        </table>
                    </div>
                    @alert(['type'=>'danger'])
                    删除之后，此用户的出题、解题记录也将全部删除。
                    @endalert
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <a role="button" href="#" class="btn btn-danger"
                       onclick="event.preventDefault();
                                document.getElementById('delete-form').submit();">
                        删除
                    </a>
                    <form id="delete-form" action="#" method="POST" style="display: none;">
                        @csrf
                        @method('DELETE')
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="curse-user-modal" tabindex="-1" role="dialog"
         aria-labelledby="curse-user-modal-label"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="edit-solution-modal-label">诅 · 咒</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="关闭">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <tr>
                                <td>用户 ID</td>
                                <td><code id="user-id"></code></td>
                            </tr>
                            <tr>
                                <td>用户名</td>
                                <td><span id="user-username"></span></td>
                            </tr>
                            <tr>
                                <td>邮箱</td>
                                <td><samp id="user-email"></samp></td>
                            </tr>
                            <tr>
                                <td>学号</td>
                                <td><samp id="user-person-id"></samp></td>
                            </tr>
                        </table>
                    </div>
                    <form id="curse-form" method="POST" action="#" class="form-inline">
                        @method('PATCH')
                        @csrf
                        <div class="form-group row">
                            <div class="col">
                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">
                                                诅咒比例
                                            </div>
                                        </div>
                                        <input type="number" class="form-control" id="curse-ratio"
                                               name="curse_ratio" required>
                                        <div class="input-group-append">
                                            <div class="input-group-text">%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    @alert(['type'=>'info'])
                    诅咒的比例范围为百分之 signed long 或者 signed long long 范围。诅咒之后所有得分叠加此比例，除此之外用户不会有任何提示信息。
                    @endalert
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <a role="button" href="#" class="btn btn-primary"
                       onclick="event.preventDefault();
                                document.getElementById('curse-form').submit();">
                        修改
                    </a>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra_js')
    <script>
        const USERS = @json($users);
        $("#delete-user-modal").on("show.bs.modal", function (event) {
            let button = $(event.relatedTarget);
            let id = button.data("id");
            let modal = $(this);
            modal.find("#user-id").text(id);
            modal.find("#user-username").text(USERS[id].username);
            modal.find("#user-email").text(USERS[id].email);
            modal.find("#user-person-id").text(USERS[id].person_id);
            modal.find("#user-total-score").text(Math.round(USERS[id].total_score * 100) / 100);
            modal.find("#delete-form").attr("action", "users/" + id);
        });
        $("#curse-user-modal").on("show.bs.modal", function (event) {
            let button = $(event.relatedTarget);
            let id = button.data("id");
            let modal = $(this);
            modal.find("#user-id").text(id);
            modal.find("#user-username").text(USERS[id].username);
            modal.find("#user-email").text(USERS[id].email);
            modal.find("#user-person-id").text(USERS[id].person_id);
            modal.find("#curse-ratio").val(USERS[id].curse_ratio);
            modal.find("#curse-form").attr("action", "users/" + id + "/curse");
        });
    </script>
@endsection
@extends('layouts.app')

@section('page_title')
    查看用户 - @parent
@endsection

@section('content')
    @component('components.jumbo')
        @slot('title', '查看用户')
        @slot('introduction', '#'.$user->id.'：'.$user->username)
        <div class="row">
            <div class="col-md-6">
                @if (session('success'))
                    @alert(['type'=>'success'])
                    {{ session('success') }}
                    @endalert
                @endif
                @if (session('error'))
                    @alert(['type'=>'danger'])
                    {{ session('error') }}
                    @endalert
                @endif
                @include('components.errors')

                <h1 class="mb-3">
                    用户资料
                    @if(Auth::check() && ($user->id == Auth::user()->id || Auth::user()->is_admin))
                        <small>
                            <a class="btn btn-outline-primary" href="{{ route('users.edit', $user) }}" role="button">
                                修改
                            </a>
                        </small>
                    @endif
                </h1>

                <div class="table-responsive">
                    <table class="table table-hover">
                        <tbody>
                        <tr>
                            <th>#</th>
                            <td>
                                {{ $user->id }}
                            </td>
                        </tr>
                        <tr>
                            <th>用户名</th>
                            <td>
                                {{ $user->username }}
                                @if($user->is_admin)
                                    <span class="badge badge-primary">管理员</span>
                                @endif
                                @if($user->is_guest)
                                    <span class="badge badge-secondary">访客</span>
                                @endif
                            </td>
                        </tr>
                        @if(Auth::check() && ($user->id == Auth::user()->id || Auth::user()->is_admin))
                            <tr>
                                <th>邮箱</th>
                                <td><samp>{{ $user->email }}</samp></td>
                            </tr>
                            <tr>
                                <th>QQ</th>
                                <td><samp>{{ $user->qq }}</samp></td>
                            </tr>
                            <tr>
                                <th>手机号</th>
                                <td><samp>{{ $user->phone }}</samp></td>
                            </tr>
                            <tr>
                                <th>学号</th>
                                <td><code>{{ $user->person_id }}</code></td>
                            </tr>
                        @endif
                        @admin
                        <tr>
                            <th>身份证号</th>
                            <td><code>{{ $user->id_number }}</code></td>
                        </tr>
                        <tr>
                            <th>姓名</th>
                            <td><code>{{ $user->name }}</code></td>
                        </tr>
                        @endadmin
                        </tbody>
                    </table>
                </div>

                @if(Auth::check() && $user->id == Auth::user()->id && Auth::user()->is_admin)
                    <h1 class="mb-3">
                        API 密钥

                        <small>
                            <a class="btn btn-outline-danger" href="#" role="button"
                               onclick="event.preventDefault();document.getElementById('revoke-form').submit();">
                                重置
                            </a>
                            <a class="btn btn-outline-primary" href="#"
                               role="button" onclick="event.preventDefault();$('.key').toggleClass('hidden-flag')">
                                显示 / 隐藏
                            </a>
                            <a class="btn btn-outline-info" href="{{ route('api_doc') }}" role="button">
                                文档
                            </a>
                        </small>
                    </h1>
                    <form id="revoke-form" action="{{ route('users.revoke_key', $user->id) }}" method="POST"
                          style="display: none;">
                        @csrf
                    </form>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tbody>
                            <tr>
                                <td>
                                    <code class="key hidden-flag">{{ $user->access_key }}</code>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                @endif

            </div>
            <div class="col-md-6">
                <h1 class="mb-3">
                    积分组成
                    <small class="text-muted">
                        共 {{ $total_score }} 分
                    </small>
                </h1>

                <div id="composition-pie">
                    <svg class="align-content-center"></svg>
                </div>
            </div>
        </div>
        @if(Auth::check() && ($user->id == Auth::user()->id || Auth::user()->is_admin))
            <hr>
            <div class="row">
                <div class="col">
                    <h1 class="mb-3">
                        提交记录
                        <small>
                            <a class="btn btn-outline-primary" href="#"
                               role="button" onclick="event.preventDefault();$('.flag').toggleClass('hidden-flag')">
                                显示 / 隐藏 flag
                            </a>
                        </small>
                    </h1>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">题目</th>
                                <th scope="col">Flag</th>
                                <th scope="col">状态</th>
                                <th scope="col">提交时间</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach ($solutions as $solution)
                                <tr>
                                    <th scope="row" class="text-nowrap">{{ $solution->id }}</th>
                                    <td>
                                        <a href="{{ route('problems.show', $solution->problem_id) }}">
                                            #{{ $solution->problem->id }}
                                            {{ $solution->problem->title }}
                                        </a>
                                    </td>
                                    <td>
                                        <code class="text-nowrap">
                                        <span class="flag hidden-flag">
                                            {{ $solution->flag }}
                                        </span>
                                        </code>
                                    </td>
                                    <td>
                                        @if($solution->is_approved)
                                            <span class="badge badge-success">
                                            通过 -
                                                {{ $solution->approved_solution->score_ratio }}%
                                        </span>
                                        @else
                                            @if($solution->problem->is_py_needed)
                                                <span class="badge badge-secondary">审核中</span>
                                            @else
                                                <span class="badge badge-danger">错误</span>
                                            @endif
                                        @endif
                                    </td>
                                    <td><samp class="text-nowrap">{{ $solution->created_at }}</samp></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endif
        @admin
        @if($user->is_admin)
            <hr>
            <div class="row">
                <div class="col">
                    <h1 class="mb-3">出题列表</h1>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">标题</th>
                                <th scope="col">类别</th>
                                <th scope="col">提交数</th>
                                <th scope="col">解出数</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach ($problems as $problem)
                                <tr>
                                    <th scope="row" class="text-nowrap">{{ $problem->id }}</th>
                                    <td><a href="{{ route('problems.show', $problem) }}">{{ $problem->title }}</a></td>
                                    <td>{{ $problem->problem_type->name }}</td>
                                    <td><code class="text-nowrap">{{ $problem->submitted }}</code></td>
                                    <td><code class="text-nowrap">{{ $problem->solved }}</code></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endif
        @endadmin
    @endcomponent
@endsection

@section('extra_css')
    <link href="https://cdnjs.cloudflare.com/ajax/libs/nvd3/1.8.6/nv.d3.min.css" rel="stylesheet">
@endsection

@section('extra_js')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.17/d3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/nvd3/1.8.6/nv.d3.min.js"></script>
    <script>
        const SCORE_COMPOSITION = @json($score_composition);

        function show_pie(selector, title, content) {
            element = $(selector);
            let w = element.width();
            let h = w * 1.2;
            element.height(h);
            nv.addGraph(function () {
                let chart = nv.models.pieChart()
                    .x(function (d) {
                        return d.type_name
                    })
                    .y(function (d) {
                        return d.total_score
                    })
                    .width(w)
                    .height(h)
                    .labelType("key")
                    .labelsOutside(true)
                    .cornerRadius(3);
                chart.title(title);
                d3.select(selector)
                    .datum(content)
                    .transition().duration(1200)
                    .call(chart);
                return chart;
            });
        }

        show_pie("#composition-pie svg", "", SCORE_COMPOSITION);
    </script>
@endsection
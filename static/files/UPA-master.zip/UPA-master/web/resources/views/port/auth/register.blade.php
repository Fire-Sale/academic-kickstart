@extends('layouts.app')

@section('page_title')
    注册 - @parent
@endsection

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">注册</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}" aria-label="注册">
                        @csrf
                        @if (session('error'))
                            @alert(['type'=>'danger'])
                            {{ session('error') }}
                            @endalert
                        @endif

                        <div class="form-group row">
                            <label for="username" class="col-md-4 col-form-label text-md-right">用户名</label>

                            <div class="col-md-6">
                                <input id="username" type="text"
                                       class="form-control{{ $errors->has('username') ? ' is-invalid' : '' }}"
                                       name="username" value="{{ old('username') }}" required autofocus>

                                @if ($errors->has('username'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('username') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">密码</label>

                            <div class="col-md-6">
                                <input id="password" type="password" minlength="10"
                                       class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}"
                                       name="password" required>

                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">确认密码</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control"  minlength="10"
                                       name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">E-Mail</label>

                            <div class="col-md-6">
                                <input id="email" type="email"
                                       class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email"
                                       value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="qq" class="col-md-4 col-form-label text-md-right">QQ</label>

                            <div class="col-md-6">
                                <input id="qq" type="text" minlength="5" maxlength="10"
                                       class="form-control{{ $errors->has('qq') ? ' is-invalid' : '' }}"
                                       name="qq" value="{{ old('qq') }}" required>

                                @if ($errors->has('qq'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('qq') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="phone" class="col-md-4 col-form-label text-md-right">手机号</label>

                            <div class="col-md-6">
                                <input id="phone" type="text" minlength="8" maxlength="11"
                                       class="form-control{{ $errors->has('phone') ? ' is-invalid' : '' }}"
                                       name="phone" value="{{ old('phone') }}" required>
                                <small id="phone-help" class="form-text text-muted">
                                    QQ 与手机号为面试通知的重要依据，请务必如实填写。
                                </small>

                                @if ($errors->has('phone'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('phone') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="person-id" class="col-md-4 col-form-label text-md-right">学号</label>

                            <div class="col-md-6">
                                <input id="person-id" type="text" minlength="8" maxlength="13"
                                       class="form-control{{ $errors->has('person_id') ? ' is-invalid' : '' }}"
                                       name="person_id" value="{{ old('person_id') }}" required>

                                @if ($errors->has('person_id'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('person_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">姓名</label>

                            <div class="col-md-6">
                                <input id="name" type="text" maxlength="16"
                                       class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
                                       name="name" value="{{ old('name') }}" required>

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="id-number" class="col-md-4 col-form-label text-md-right">身份证号</label>

                            <div class="col-md-6">
                                <input id="id-number" type="text" maxlength="18"
                                       class="form-control{{ $errors->has('id_number') ? ' is-invalid' : '' }}"
                                       name="id_number" value="{{ old('id_number') }}" required>
                                <small id="person-help" class="form-text text-muted">
                                    个人信息仅用于认证，我们保证不会透露给第三方。
                                </small>

                                @if ($errors->has('id_number'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('id_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="invitation-code" class="col-md-4 col-form-label text-md-right">邀请码</label>

                            <div class="col-md-6">
                                <input id="invitation-code" type="password"
                                       class="form-control{{ $errors->has('invitation_code') ? ' is-invalid' : '' }}"
                                       name="invitation_code" value="{{ old('invitation_code') }}" autocomplete="off">
                                <small id="invitation-code-help" class="form-text text-muted">非管理员注册无须填写。</small>

                                @if ($errors->has('invitation_code'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('invitation_code') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-info">
                                    注册
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@extends('layouts.app')

@section('page_title')
    编辑题目 - @parent
@endsection

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">编辑题目</div>

                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data" action="{{ route('problems.update', $problem->id) }}" aria-label="创建题目">
                        @csrf
                        @method('PATCH')

                        <div class="form-group row">
                            <label for="title" class="col-md-4 col-form-label text-md-right">标题</label>

                            <div class="col-md-6">
                                <input id="title" type="text"
                                       class="form-control{{ $errors->has('title') ? ' is-invalid' : '' }}"
                                       name="title" value="{{ $problem->title }}" required autofocus>
                                <small class="form-text text-muted">
                                    长度不超过 64 位。
                                </small>

                                @if ($errors->has('title'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('title') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right">类别</label>
                            <div class="col-md-6">
                                <select class="form-control{{ $errors->has('type') ? ' is-invalid' : '' }}" id="type" name="type">
                                    <option value="0">---</option>
                                    @foreach($types as $type)
                                        <option value="{{ $type->id }}" {{ old('type') == $type->id || (!old('type') && ($problem->type_id == $type->id)) ? 'selected' : '' }}>{{ $type->name }}</option>
                                    @endforeach
                                </select>

                                @if ($errors->has('type'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('type') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="score" class="col-md-4 col-form-label text-md-right">基准分值</label>

                            <div class="col-md-6">
                                <input id="score" type="number"
                                       class="form-control{{ $errors->has('score') ? ' is-invalid' : '' }}"
                                       name="score" value="{{ old('score') ?? $problem->score }}" required>
                                <small id="score-help" class="form-text text-muted">
                                    做出默认得到 100% 分值，出题人可在题目界面修改任意人此题分数。
                                </small>

                                @if ($errors->has('score'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('score') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="flag" class="col-md-4 col-form-label text-md-right">Flag</label>

                            <div class="col-md-6">
                                <input id="flag" type="text" placeholder="flag{Ch1_4iA0_4iA0}"
                                       class="form-control{{ $errors->has('flag') ? ' is-invalid' : '' }}"
                                       name="flag" value="{{ old('flag') ?? $problem->flag }}">
                                <small class="form-text text-muted">
                                    长度不超过 64 位。
                                </small>

                                @if ($errors->has('flag'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('flag') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <hr>

                        <div class="form-group row">
                            <label for="attachment" class="col-md-4 col-form-label text-md-right">附件</label>

                            <div class="col-md-6">
                                <input type="file" class="form-control-file{{ $errors->has('attachment') ? ' is-invalid' : '' }}" id="attachment" name="attachment">

                                <small class="form-text text-muted">
                                    大小不超过 100M。
                                </small>

                                @if ($errors->has('attachment'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('attachment') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="attachment-url" class="col-md-4 col-form-label text-md-right">附件名</label>

                            <div class="col-md-6">
                                <input id="attachment-url" type="text" placeholder="summer2018/Ch1_4iA0_4iA0.zip"
                                       class="form-control{{ $errors->has('attachment_url') ? ' is-invalid' : '' }}"
                                       name="attachment_url" value="{{ old('attachment_url') ?? $problem->attachment }}">
                                <small class="form-text text-primary">
                                    如不修改附件，请保持此两处不变。
                                </small>

                                @if ($errors->has('attachment_url'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('attachment_url') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="clear-attachment" name="clear_attachment" {{ old('clean_attachment') ? 'checked' : '' }}>
                                    <label class="form-check-label" for="clear-attachment">删除附件</label>
                                    <small class="form-text text-muted">
                                        选中将清除附件。
                                    </small>
                                </div>
                            </div>
                        </div>

                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#file-modal">
                            关于附件的说明
                        </button>

                        <hr>

                        <div class="form-group row">
                            <label for="background-color" class="col-md-4 col-form-label text-md-right">卡片背景色</label>

                            <div class="col-md-6">
                                <input id="background-color" type="text" placeholder="#233333"
                                       class="form-control{{ $errors->has('background_color') ? ' is-invalid' : '' }}"
                                       name="background_color" value="{{ old('background_color') ?? $problem->background_color }}">
                                <small id="background-color-help" class="form-text text-muted">
                                    为空将随机生成。
                                </small>

                                @if ($errors->has('background_color'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('background_color') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="background-image" class="col-md-4 col-form-label text-md-right">卡片背景图</label>

                            <div class="col-md-6">
                                <input type="file" class="form-control-file{{ $errors->has('attachment') ? ' is-invalid' : '' }}" id="background-image" name="background_image">

                                <small id="background-image-help" class="form-text text-muted">
                                    不修改请留空。如已设置背景图，则背景色无效。<br>推荐尺寸为 500x292，非此比例可能会被拉抻。
                                </small>

                                @if ($errors->has('background_image'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('background_image') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="clear-background-image" name="clear_background_image" {{ old('clear_background_image') ? 'checked' : '' }}>
                                    <label class="form-check-label" for="clear-background-image">删除背景图</label>
                                    <small class="form-text text-muted">
                                        选中将清除背景图。
                                    </small>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="form-group">
                            <label for="content">正文</label>
                            <textarea class="form-control" id="content" name="content" required>{{ old('content') ?? $problem->content }}</textarea>
                        </div>

                        <div class="form-group row">
                            <div class="col">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="published" name="is_published" {{ old('is_published') || $problem->is_published ? 'checked' : '' }}>
                                    <label class="form-check-label" for="published">发布</label>
                                    <small id="published-help" class="form-text text-muted">
                                        未发布的状态下，只有管理员能查看题目、提交解答。<br>从发布状态修改为未发布时，已提交的解答不会受影响。
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-info">
                                    编辑
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="file-modal" tabindex="-1" role="dialog" aria-labelledby="file-modal-label" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="file-modal-label">关于附件的说明</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>为实现附件分流，本平台的附件与网站文件分开存放，通过 FTP 上传。</p>
                    <p>直接通过网页上传，将经过网站中转至 FTP 服务器，速度较慢，且有最大文件限制。</p>
                    <p>故有附件时，推荐的上传方式如下：</p>
                    <ul>
                        <li>对于 <code>10 MiB</code> 以内的小文件，直接通过网页上传。</li>
                        <li>对于大文件，可自行上传至 <code>ftp://{{config('filesystems.disks.ftp.host')}}</code>，推荐存入
                            <code>{{config('filesystems.disks.ftp.path')}}</code> 文件夹中。用户名：<code>{{ config('filesystems.disks.ftp.username') }}</code>，密码：<code>{{ config('filesystems.disks.ftp.password') }}</code>。</li>
                        <li>如传至 <code>{{config('filesystems.disks.ftp.path')}}</code> 文件夹中，名为 <code>cdd.zip</code>，则"附件名"应填入 <code>{{config('filesystems.disks.ftp.path')}}/cdd.zip</code>。</li>
                        <li>也可上传至百度云等网盘，在正文内通过 markdown 链接提供下载地址。</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra_js')
    <script type="text/javascript">
        var ele_textarea = document.getElementById('content');
        var editor = new mditor(ele_textarea);
    </script>
@endsection

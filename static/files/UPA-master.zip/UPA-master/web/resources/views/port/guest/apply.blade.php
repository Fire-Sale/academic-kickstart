@extends('layouts.app')

@section('page_title')
    访客申请 - @parent
@endsection

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">访客申请</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('guests.store') }}" aria-label="访客申请">
                        @csrf
                        @alert(['type'=>'info'])
                        <h4 class="alert-heading">访客账户</h4>
                        <p>为维护招新环境，本平台普通用户只允许校内同学注册。校外同学可通过此页面申请访客账户，管理员审核通过后即可登录并浏览题目、参与解题。</p>
                        <p>访客账户具有以下限制：</p>
                        <ul>
                            <li>分数不计入排行榜，仅自己与管理员可见。</li>
                            <li>提交不影响题目解答计数，即不会影响题目分数。</li>
                        </ul>
                        <p>校内同学请点击「注册」按钮进行正常注册。</p>
                        @endalert
                        @if (session('success'))
                            @alert(['type'=>'success'])
                            {{ session('success') }}
                            @endalert
                        @endif
                        @if (session('error'))
                            @alert(['type'=>'danger'])
                            {{ session('error') }}
                            @endalert
                        @endif

                        <div class="form-group row">
                            <label for="username" class="col-md-4 col-form-label text-md-right">用户名</label>

                            <div class="col-md-6">
                                <input id="username" type="text"
                                       class="form-control{{ $errors->has('username') ? ' is-invalid' : '' }}"
                                       name="username" value="{{ old('username') }}" required autofocus>

                                @if ($errors->has('username'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('username') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">密码</label>

                            <div class="col-md-6">
                                <input id="password" type="password" minlength="10"
                                       class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}"
                                       name="password" required>

                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">确认密码</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control"  minlength="10"
                                       name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">E-Mail</label>

                            <div class="col-md-6">
                                <input id="email" type="email"
                                       class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email"
                                       value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="qq" class="col-md-4 col-form-label text-md-right">QQ</label>

                            <div class="col-md-6">
                                <input id="qq" type="text" minlength="5" maxlength="10"
                                       class="form-control{{ $errors->has('qq') ? ' is-invalid' : '' }}"
                                       name="qq" value="{{ old('qq') }}" required>
                                <small id="phone-help" class="form-text text-muted">
                                    管理员可能通过 QQ 确认申请，请务必如实填写。
                                </small>

                                @if ($errors->has('qq'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('qq') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="from" class="col-md-4 col-form-label text-md-right">学校与年级</label>

                            <div class="col-md-6">
                                <input id="from" type="text"
                                       class="form-control{{ $errors->has('from') ? ' is-invalid' : '' }}"
                                       name="from" value="{{ old('from') }}" required>

                                @if ($errors->has('from'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('from') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="reason" class="col-md-4 col-form-label text-md-right">申请理由</label>

                            <div class="col-md-6">
                                <textarea id="reason" type="text"
                                       class="form-control{{ $errors->has('reason') ? ' is-invalid' : '' }}"
                                       name="reason" value="{{ old('reason') }}" required></textarea>

                                @if ($errors->has('reason'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('reason') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-info">
                                    提交
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

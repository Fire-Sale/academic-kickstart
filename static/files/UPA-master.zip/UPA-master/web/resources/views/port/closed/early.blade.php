<!DOCTYPE html>
<html lang="zh">

<head>
    <meta charset="utf-8">
    <title>
        CNSS Recruit 2018 - Coming Soon
    </title><!-- Behavioral Meta Data -->
    <meta content="yes" name="apple-mobile-web-app-capable">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <!-- CSS -->
    <link href='https://fonts.loli.net/css?family=Roboto:400,100,900' rel='stylesheet' type='text/css'><!-- Styles -->
    <link rel="stylesheet" href="{{ url('css/countdown/loader.css') }}">
    <link rel="stylesheet" href="{{ url('css/countdown/normalize.css') }}">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="{{ url('css/countdown/style.css') }}" rel="stylesheet" type="text/css">
    <!-- Javascript -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

    <meta name="msapplication-TileColor" content="#00aba9">
    <meta name="theme-color" content="#ffffff">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ url('apple-touch-icon.png') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ url('favicon-32x32.png') }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ url('favicon-16x16.png') }}">
    <link rel="manifest" href="{{ url('site.webmanifest') }}">
    <link rel="mask-icon" href="{{ url('safari-pinned-tab.svg') }}" color="#5bbad5">
</head>
<body>
<div class="preloader">
    <div class="loading">
        <h2>
            Loading...
        </h2>
        <span class="progress"></span>
    </div>
</div>

<div class="wrapper">
    <ul class="scene unselectable" data-friction-x="0.1" data-friction-y="0.1" data-scalar-x="25" data-scalar-y="15" id="scene">
        <li class="layer" data-depth="0.00">
        </li>
        <!-- BG -->

        <li class="layer" data-depth="0.10">
            <div class="background">
            </div>
        </li>

        <!-- Hero -->

        <li class="layer" data-depth="0.25">
            <div class="sphere">
                <img alt="sphere" src="{{ url('img/countdown/sphere.png') }}">
            </div>
        </li>

        <li class="layer" data-depth="0.30">
            <div class="hero">
                <h1 id="countdown">
                    CNSS Recruit 2018 - Coming Soon
                </h1>

                <p class="sub-title">
                    CNSS Recruit 2018 - Coming Soon
                </p>
            </div>
        </li>
        <!-- Flakes -->

        <li class="layer" data-depth="0.40">
            <div class="depth-1 flake1">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth1/flakes1.png') }}">
            </div>

            <div class="depth-1 flake2">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth1/flakes2.png') }}">
            </div>

            <div class="depth-1 flake3">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth1/flakes3.png') }}">
            </div>

            <div class="depth-1 flake4">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth1/flakes4.png') }}">
            </div>
        </li>

        <li class="layer" data-depth="0.50">
            <div class="depth-2 flake1">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth2/flakes1.png') }}">
            </div>

            <div class="depth-2 flake2">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth2/flakes2.png') }}">
            </div>
        </li>

        <li class="layer" data-depth="0.60">
            <div class="depth-3 flake1">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth3/flakes1.png') }}">
            </div>

            <div class="depth-3 flake2">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth3/flakes2.png') }}">
            </div>

            <div class="depth-3 flake3">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth3/flakes3.png') }}">
            </div>

            <div class="depth-3 flake4">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth3/flakes4.png') }}">
            </div>
        </li>

        <li class="layer" data-depth="0.80">
            <div class="depth-4">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth4/flakes.png') }}">
            </div>
        </li>

        <li class="layer" data-depth="1.00">
            <div class="depth-5">
                <img alt="flake" src="{{ url('img/countdown/flakes/depth5/flakes.png') }}">
            </div>
        </li>
        <!-- Contact -->

        <li class="layer" data-depth="0.20">
            <div class="contact">
                <ul class="icons">
                    <li>
                        <a class="key" href="{{ route('login') }}"><i class="fa fa fa-key"></i></a>
                    </li>

                    <li>
                        <a class="pencil" href="{{ route('register') }}"><i class="fa fa-pencil"></i></a>
                    </li>
                </ul>
                Page from <a href="https://github.com/technext/Imminent" target="_blank">Imminent</a>
            </div>
        </li>
    </ul>
</div>

<!-- Javascript -->
<script src="{{ url('js/countdown/plugins.js') }}"></script>
<script src="{{ url('js/countdown/jquery.countdown.min.js') }}"></script>
<script src="{{ url('js/countdown/main.js') }}"></script>

</body>
</html>
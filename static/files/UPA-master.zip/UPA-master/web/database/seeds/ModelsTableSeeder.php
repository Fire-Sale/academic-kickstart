<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ModelsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('models')->insert([
            'name' => 'DJI Inspire 1',
            'abilities' => json_encode([
                'fruit_count',
                'bug_detection',
            ]),
        ]);
        DB::table('models')->insert([
            'name' => 'DJI Inspire 2',
            'abilities' => json_encode([
                'fruit_count',
                'bug_detection',
            ]),
        ]);
    }
}

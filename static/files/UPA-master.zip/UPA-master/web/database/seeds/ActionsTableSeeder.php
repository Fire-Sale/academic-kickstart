<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ActionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('actions')->insert([
            'name' => '果实计数',
            'ability' => 'fruit_count',
        ]);
        DB::table('actions')->insert([
            'name' => '病虫害检测',
            'ability' => 'bug_detection',
        ]);
    }
}

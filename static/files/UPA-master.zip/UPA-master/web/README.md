# Web 管理界面

## 配置

1. 在本目录运行 docker build 指令，如 `docker build -t web:1 .`，即可构建本系统的镜像。
2. 运行 docker run 命令，运行刚才构建的镜像，并将其 8000 端口映射出来，如 `docker run -it --name=web -p 8000:8000 web:1`，即可从外部访问。

## 使用

请见 [相关视频](https://share.weiyun.com/5hDaGoy)。


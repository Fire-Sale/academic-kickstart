<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Device extends Model
{
    protected $casts = [
        'parameters' => 'array',
    ];

    protected $fillable = ['name', 'model_id', 'color', 'sn', 'parameters'];

    public function records()
    {
        return $this->hasMany('App\Record');
    }

    public function model()
    {
        return $this->belongsTo('App\Model');
    }
}

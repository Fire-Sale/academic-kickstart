<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Record extends Model
{
    protected $casts = [
        'detail' => 'array',
    ];

    protected $fillable = ['area_id', 'device_id', 'action_id', 'status', 'detail'];

    public function device()
    {
        return $this->belongsTo('App\Device');
    }

    public function area()
    {
        return $this->belongsTo('App\Area');
    }

    public function action()
    {
        return $this->belongsTo('App\Action');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Area extends Model
{
    protected $casts = [
        'parameters' => 'array'
    ];

    protected $fillable = ['name', 'color', 'path', 'parameters'];

    public function records()
    {
        return $this->hasMany('App\Record');
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Area;

class IndexController extends Controller
{
    public function index()
    {
        $area_count = Area::all()->count();
        $device_count = Area::all()->count();

        return view('index', [
            'area_count' => $area_count,
            'device_count' => $device_count,
        ]);
    }
}

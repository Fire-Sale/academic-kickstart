<?php

namespace App\Http\Controllers;

use App\Action;
use App\Area;
use App\Device;
use App\Record;
use Illuminate\Http\Request;

class RecordController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $records = Record::with('device.model')->with('action')->with('area')->get();

        return view('records.index', ['records' => $records]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'area_id' => 'required|numeric|exists:areas,id',
            'action_id' => 'required|numeric|exists:actions,id',
            'device_id' => 'required|numeric|exists:devices,id',
        ]);

        $area = Area::find($validated['area_id']);
        $action = Action::find($validated['action_id']);
        $device = Device::find($validated['device_id']);

        if (!in_array($action->ability, $device->model->abilities)) {
            return redirect()->back()->withInput()->with('error', '此机型无法执行此任务。');
        }

        $record = new Record();
        $record->fill([
            'area_id' => $area->id,
            'action_id' => $action->id,
            'device_id' => $device->id,
            'status' => 'pending',
            'detail' => [],
        ]);
        $record->save();

        return redirect()->route('records.index')->with('success', '指派任务成功。');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Record  $record
     * @return \Illuminate\Http\Response
     */
    public function show(Record $record)
    {
        return view('records.show', ['record' => $record]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Record  $record
     * @return \Illuminate\Http\Response
     */
    public function destroy(Record $record)
    {
        $record->delete();

        return redirect()->back()->with('success', '删除任务记录成功。');
    }
}

<?php

namespace App\Http\Controllers;

use App\Device;
use App\Model;
use Illuminate\Http\Request;

class DeviceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $devices = Device::with('model')->get();
        $devices_to_show = [];
        foreach ($devices as $device) {
            $devices_to_show[$device->id] = $device;
        }

        return view('devices.index', ['devices' => $devices_to_show]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $models = Model::all();

        return view('devices.create', ['models' => $models]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:16',
            'model' => 'required|numeric|exists:models,id',
            'sn' => 'required|string|max:16',
            'secret' => 'required|string|size:8',
        ]);

        $device = new Device();
        $device->fill([
            'name' => $validated['name'],
            'model_id' => $validated['model'],
            'sn' => $validated['sn'],
            'parameters' => []
        ]);
        $device->save();

        return redirect()->route('devices.index')->with('success', '关联设备成功。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Device  $device
     * @return \Illuminate\Http\Response
     */
    public function destroy(Device $device)
    {
        $device->delete();

        return redirect()->route('devices.index')->with('success', '删除设备成功。');
    }
}

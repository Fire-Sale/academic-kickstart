# PaddlePaddle Fluid 物体检测模型

概述：使用PaddlePaddle Fluid实现物体检测模型（Mobile Net SSD）的分布式多机训练以及内存优化。

[TOC]

## 准备工作

安装最新版的 PaddlePaddle Fluid 以及其依赖，安装 VisualDL

所有 Python 库依赖都在 `requirements.txt `里，请安装这些库

```shell
pip install -r requirements.txt
```

但是，我们更推荐使用 `docker` 来运行程序,

```shell
docker run -it --runtime=nvidia -v $PWD:/work paddlepaddle/paddle:latest-gpu /bin/bash
```

## 	数据准备

### 下载数据集

下载 [download]，将 `data/` 目录解压到项目 `object_detection/data/` 目录下

数据已经过预处理，不需要再执行预处理脚本

请查阅 `data_preprocess.py` 以获得数据处理相关的信息

### 下载训练好的模型

下载 [download]，将 `model/` 目录解压到项目 `object_detection/model/` 目录下


## 训练模型

得益于 PaddlePaddle Fluid 框架，训练脚本可以在多台机器上执行分布式训练

如果想保持简单，请直接运行

```shell
python train.py
```

---

`train.py` 是训练模型的主程序，使用方法为：

```shell
export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
python -u train.py --use_gpu=True --parallel=True --distribute=False --batch_size=64 --memory_optimize=True
```

- 使用参数 `--use_gpu=True` 来使用 GPU

- 使用参数 `--parallel=True` 来使用多个 GPU

- 设置环境变量 `export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7` 来指定多 GPU 训练时要使用的 GPU 编号

- 使用参数 `--distribute=True` 来启动分布式训练，有关分布式训练的更多帮助请查看下文 [分布式训练]

- 使用参数 `memory_optimize=True` 来对 LoDTensors 执行内存优化

- 更多帮助请执行

  ```shell
  python train.py --help
  ```

### 分布式训练

#### 准备工作

若执行分布式训练，则需要编译分布式版本的 PaddlePaddle Fluid

编译 PaddlePaddle 的方法可以在[这里](http://www.paddlepaddle.org/docs/develop/documentation/en/getstarted/build_and_install/index_en.html)找到

执行 `cmake` 指令时，请设置参数 `-DWITH_DISTRIBUTE=ON` 以编译分布式版本的 PaddlePaddle，示例：

```shell
cmake .. -DWITH_DOC=OFF -DWITH_GPU=OFF -DWITH_DISTRIBUTE=ON -DWITH_SWIG_PY=ON -DWITH_PYTHON=ON
```

#### 执行训练

执行分布式训练时，需要带上额外的参数指定服务器角色和主机地址，参数列表如下：

| 参数            | 键值类型 | 描述                                                        | 示例                          |
| --------------- | -------- | ----------------------------------------------------------- | ----------------------------- |
| trainer_id      | int      | 当前训练节点的ID，训练节点ID编号为0 - n-1， n为trainers的值 | 0                             |
| pservers        | str      | parameter server 列表                                       | 127.0.0.1:6710,127.0.0.1:6711 |
| trainers        | int      | 训练节点的总个数，>0的数字                                  | 4                             |
| server_endpoint | str      | 当前所起的服务节点的IP:PORT                                 | 127.0.0.1:8789                |
| training_role   | str      | 节点角色， TRAINER/PSERVER                                  | TRAINER                       |

## 评估模型

使用 `eval.py` 来通过 `mAP` 评估模型：

```shell
python eval.py --use_gpu=True
```

训练集和测试集已经过二八分，`test_file_list.txt` 中的图片专用于评估模型
我们训练好的模型在 `model/best_model_test` 下，精准度超过 99%

## 预测和绘制图像

使用 `infer.py` 来通过模型预测，示例：

```shell
python infer.py --use_gpu=True --confs_threshold=0.5 --model_dir='trained_models/best_model' --image_path='./data/orange/test.jpg'
```

- 使用参数 `--confs_threshold=0.5` 来指定绘制红框的置信值阀值

- 使用参数 `--image_path='test.jpg'` 来指定输入图像

- 使用参数 `use_gpu=True` 来使用 GPU

- 更多帮助请执行

  ```shell
  python infer.py --help
  ```

![apple](./images/apple.JPG)

注：得益于 PaddlePaddle Fluid 的 ProgramDesc 设计，使用多 GPU 或者分布式集群训练得到的模型能在单个 GPU 或者 CPU 上执行预测

## 可视化训练过程

VisualDL 可以用来可视化训练过程

在训练结束后，执行

```shell
visualdl --logdir ./log --port 8080
```

然后在浏览器中打开 `http://localhost:8080` 即可


# Mobile Net SSD PaddlePaddle Fluid

Overview: Implement parallel and distribute training and memory optimization with PaddlePaddle Fluid to SSD object detection model.

[TOC]

## Pre-requirements

The minimum PaddlePaddle version needed for the code sample in this directory is the latest develop branch. And [VisualDL](https://github.com/PaddlePaddle/VisualDL) is needed to be installed to visualize the training process.

All the packages needed is in `requirements.txt`, install these packages.

```shell
pip install -r requirements.txt
```

however, `docker` is recommended instead of `pip`,

```shell
docker run -it --runtime=nvidia -v $PWD:/work paddlepaddle/paddle:latest-gpu /bin/bash
```

## Data Preparation

### Dataset

Download [download], and unzip `data/` directory to `object_detection/data`

The data is already modified for the model, no more pre-processing script is needed.

Infer `data_preprocess.py` for more detials about the dataset

### Trained Model

Download [download], and unzip `model/` directory to `object_detection/model`

## Train

With the help of PaddlePaddle Fluid framework, the script can run **parallel** training on multi-gpus and **distributed** training on the cluster.

If you want to keep things simple, just run

```shell
python train.py
```

---

`train.py` is the main process of the training module. Examples of usage are shown below. 

```shell
export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
python -u train.py --use_gpu=True --parallel=True --distribute=False --batch_size=64 --memory_optimize=True
```

- set `--use_gpu=True` to use GPU

- set `--parallel=True` to train on multi-GPUs

- set `export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7` to specifiy the GPU you want to use on multi-GPUs training

- set `--distribute=True` to enable distributed training on multiple servers see [Distributed Training] for more help

- set `memory_optimize=True` to apply memory optimization to the LoDTensors

- for more help on arguments:

  ```shell
  python train.py --help
  ```

### Distributed Training

#### Preparations

To enable distributed training the distributed version of PaddlePaddle is needed

PaddlePaddle build and installation guide can be found  [here](http://www.paddlepaddle.org/docs/develop/documentation/en/getstarted/build_and_install/index_en.html).

In addition to above, the `cmake` command should be run with the option `WITH_DISTRIBUTE` set to on. An example bare minimum `cmake` command would look as follows:

``` bash
cmake .. -DWITH_DOC=OFF -DWITH_GPU=OFF -DWITH_DISTRIBUTE=ON -DWITH_SWIG_PY=ON -DWITH_PYTHON=ON
```
#### Runtime

The parameters required in distributed training is list as follow:

| parameter       | type | description                                       | example                       |
| --------------- | ---- | ------------------------------------------------- | ----------------------------- |
| trainer_id      | int  | the id for current trainer, 0 ~ n-1                       | 0                             |
| pservers        | str  | list of parameter servers                         | 127.0.0.1:6710,127.0.0.1:6711 |
| trainers        | int  | number of trainers                                | 4                             |
| server_endpoint | str  | IP:PORT for current server                        | 127.0.0.1:8789                |
| training_role   | str  | training role for current server, TRAINER/PSERVER | TRAINER                       |


## Evaluation

Run `eval.py` to evaluate the model by `mAP`

```shell
python eval.py --use_gpu=True
```

We provided well-tuned model at `mode/best_model_test` with a mAP over 99% on the test set.


## Infer and Draw Image

Run `infer.py` to use the inferring module. Examples of usage are shown below.

```shell
python infer.py --use_gpu=True --confs_threshold=0.5 --model_dir='trained_models/best_model' --image_path='./data/orange/test.jpg'
```

- set `--confs_threshold=0.5` to specifiy the threshold to draw bbox

- set `--image_path='test.jpg'` to feed image

- set `use_gpu=True` to use GPU

- for more help on arguments:

  ```shell
  python infer.py --help
  ```

![apple](./images/apple.JPG)

PS. With the help of ProgramDesc from PaddlePaddle Fluid, the model trained on multi-GPU or even distributed cluster can be loaded on any device. By default, the program only use a single GPU or CPU to run the infer process.

## Visualize the Training Process

VisualDL can be used to visualize the training process.

After the training process is done, call

```shell
visualdl --logdir ./log --port 8080
```

Then open `http://127.0.0.1:8080` with your browser.
